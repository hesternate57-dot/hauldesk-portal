# HaulDesk — Complete System Architecture Blueprint
**Classification:** Technical Architecture Specification  
**Version:** 2.0 | **Status:** Approved for Development  
**Scope:** All phases, all domains, production-grade  

---

## Executive Summary

HaulDesk is a multi-tenant AI freight dispatching platform serving independent carriers and small fleets. The architecture is designed to handle thousands of concurrent loads, thousands of broker relationships, real-time updates, autonomous AI outreach, and full financial settlement tracking — while keeping a human in the approval seat for any action that commits money or equipment.

**Core design principles:**
- **Human-in-the-loop:** AI prepares, human confirms. No autonomous money commitments.
- **Source-agnostic data ingestion:** Load data from DAT, Truckstop, or direct broker email through a unified ingestion layer.
- **Event-driven:** All async work (polling, outreach, OCR, scoring) runs through a job queue — never blocking the user.
- **Multi-tenant from day one:** Every database query, every storage path, every API call is scoped to a company_id.
- **Defense in depth:** Authentication, authorization, and data isolation enforced at three independent layers.

---

## 1. Frontend Architecture

### Framework & Structure
```
Next.js 14 (App Router)
├── app/
│   ├── (auth)/
│   │   ├── login/
│   │   └── onboarding/
│   ├── (freight)/                     ← Freight portal
│   │   ├── loads/                     ← Load board (Phase 2)
│   │   ├── outreach/                  ← Broker outreach (Phase 3)
│   │   ├── bookings/                  ← Approvals + booking (Phase 4)
│   │   └── dispatch/                  ← Active dispatch (Phase 5)
│   ├── (settlement)/                  ← Settlement portal
│   │   ├── dashboard/                 ← Executive summary (Phase 6)
│   │   ├── transactions/
│   │   ├── receipts/
│   │   ├── budgets/
│   │   └── reports/
│   ├── fleet/                         ← Trucks + drivers
│   ├── account/                       ← Profile, billing, team
│   └── api/                           ← Next.js API routes (webhooks)
├── components/
│   ├── ui/                            ← Design system primitives
│   ├── loads/                         ← Load-specific components
│   ├── outreach/                      ← Email thread components
│   ├── settlement/                    ← Financial components
│   └── shared/                        ← Cross-domain components
├── lib/
│   ├── trpc/                          ← tRPC client setup
│   ├── stores/                        ← Zustand state stores
│   └── hooks/                         ← Shared React hooks
└── public/
```

### State Management
| Concern | Solution | Rationale |
|---|---|---|
| Server state (loads, brokers, bookings) | TanStack Query (React Query) | Caching, background refetch, optimistic updates |
| Global UI state (sidebar, portal, modals) | Zustand | Lightweight, no boilerplate |
| Form state | React Hook Form + Zod | Validation schemas shared with backend |
| Real-time (load updates, notifications) | Supabase Realtime subscriptions | WebSocket-based, no extra infra |

### Design System
- **Component library:** Radix UI (headless, accessible primitives)
- **Styling:** Tailwind CSS with CSS custom properties for theming
- **Icons:** Lucide React
- **Charts:** Recharts (load analytics, settlement dashboards)
- **Tables:** TanStack Table (sortable, filterable, virtualized for thousands of loads)
- **Rich text (email editor):** TipTap
- **File uploads:** react-dropzone

### Performance Strategy
- **Route-level code splitting:** Automatic via Next.js App Router
- **Infinite scroll + virtualization:** TanStack Virtual for large load lists
- **Optimistic updates:** Booking status, load passing — UI updates instantly, server confirms
- **Skeleton loaders:** Every data-fetching component has a skeleton state
- **Image optimization:** Next.js Image component, Cloudflare CDN
- **Bundle target:** < 200kb initial JS, < 1s LCP on 4G

### Responsive Breakpoints
```
Mobile:   375px  → Single-column, sidebar as drawer
Tablet:   768px  → Collapsed sidebar, 2-col grid
Desktop: 1280px  → Full sidebar, 3-col load board
Wide:    1600px  → 4-col load board, expanded analytics
```

---

## 2. Backend Architecture

### API Layer
```
tRPC (Type-safe RPC)
├── Routers (organized by domain)
│   ├── auth.*              → Session validation, role checks
│   ├── loads.*             → Load search, scoring, status
│   ├── preferences.*       → Company load preferences
│   ├── outreach.*          → Email threads, drafts, sends
│   ├── brokers.*           → Broker CRM
│   ├── bookings.*          → Booking workflow + approvals
│   ├── dispatches.*        → Dispatch management
│   ├── settlements.*       → Financial tracking
│   ├── receipts.*          → Upload, OCR, categorization
│   ├── trucks.*            → Fleet management
│   ├── drivers.*           → Driver management
│   ├── notifications.*     → Notification feed
│   └── analytics.*         → Aggregated reporting
├── Middleware (applied per router)
│   ├── auth middleware      → Verify Clerk JWT
│   ├── company middleware   → Extract + validate company_id
│   ├── role middleware      → Check permissions per procedure
│   ├── rate limit middleware → Upstash Redis rate limiting
│   └── audit middleware     → Write audit log on mutations
```

### Service Layer
```
services/
├── LoadDiscoveryService
│   ├── searchDAT(lane, prefs)          → DAT Connect API
│   ├── searchTruckstop(lane, prefs)    → Truckstop API
│   ├── deduplicateLoads(loads)         → Hash-based dedup
│   └── ingestLoads(loads, company_id) → DB write + score job
│
├── AIService
│   ├── scoreLoad(load, prefs)          → Claude Haiku scoring
│   ├── draftOutreach(load, broker)     → Claude Sonnet email
│   ├── draftNegotiation(thread)        → Claude Sonnet counter
│   ├── parseInboundEmail(email)        → Claude Haiku parsing
│   └── generateInsights(data)         → Claude Sonnet analysis
│
├── EmailService
│   ├── sendOutreach(thread)            → Resend API
│   ├── handleInbound(webhook)          → Parse + route reply
│   └── buildThread(messages)          → Thread reconstruction
│
├── OCRService
│   ├── extractReceipt(file)            → AWS Textract
│   ├── validateExtraction(result)      → Confidence scoring
│   └── categorizeExpense(data)        → Claude Haiku
│
├── BookingService
│   ├── createPending(load, rate)       → Requires human approval
│   ├── approveBooking(id, user_id)     → Human confirmation gate
│   └── cancelBooking(id)              → With audit trail
│
└── SettlementService
    ├── createSettlement(booking_id)    → After delivery
    ├── updateCosts(id, costs)          → Fuel, fees, etc.
    └── generateReport(period)         → P&L export
```

### Job Queue Architecture (BullMQ)
```
Queue: lane-polling
  Schedule: every 15 min per active company
  Job: PollLanesJob
    → Load company preferences
    → Call DAT/Truckstop for each saved lane
    → Deduplicate against existing loads
    → Enqueue: score-loads for new discoveries

Queue: score-loads
  Concurrency: 10
  Job: ScoreLoadJob
    → Call Claude Haiku with load + preferences
    → Write score + breakdown to loads table
    → If score ≥ threshold + auto_outreach=true:
        Enqueue: draft-outreach

Queue: draft-outreach
  Concurrency: 5
  Job: DraftOutreachJob
    → Call Claude Sonnet to draft email
    → Store as draft in email_threads
    → Send notification to dispatcher
    → If auto_send=true: enqueue send-email
    → (Default: human reviews first)

Queue: send-email
  Concurrency: 3
  Retry: 3x with exponential backoff
  Job: SendEmailJob
    → Call Resend API
    → Store message_id and thread_id
    → Update thread status to 'sent'

Queue: process-inbound
  Job: InboundEmailJob (triggered by webhook)
    → Claude Haiku parses reply
    → Extract: rate, acceptance, decline, counter
    → Update load + thread status
    → If counter-offer: enqueue draft-negotiation
    → Send notification to dispatcher

Queue: ocr-process
  Concurrency: 5
  Job: OCRJob
    → Download file from R2
    → Send to AWS Textract
    → Parse result with Claude
    → Write structured data to receipts table
    → Notify user

Queue: report-generation
  Job: ReportJob (on-demand)
    → Query settlement + transaction data
    → Generate PDF via Puppeteer
    → Upload to R2
    → Send download link notification
```

### Webhook Handlers (Next.js API Routes)
```
/api/webhooks/
├── resend          → Inbound email (triggers process-inbound job)
├── clerk           → User created/deleted/role changed
├── stripe          → Subscription events (billing)
└── truckstop       → Load status updates (if supported)
```

---

## 3. Database Architecture

### Engine & Hosting
**PostgreSQL 16** hosted on **Supabase**

Rationale: ACID compliance, JSONB flexibility for raw API responses, Supabase Realtime for WebSocket subscriptions, built-in Row Level Security, automated backups, point-in-time recovery.

### Multi-Tenancy Pattern
Every table that contains company data carries `company_id UUID NOT NULL`. Row Level Security policies are enabled on all such tables, enforcing `company_id = auth.company_id()` at the Postgres layer — a second line of defense behind the application-layer tenant check.

### Schema (Complete — All Phases)
```
Core Identity
├── companies                 → Multi-tenant root
├── users                     → Clerk-linked, role-based
├── audit_logs                → Immutable action trail

Fleet
├── trucks                    → Equipment inventory
├── drivers                   → Driver roster

Load Discovery (Phase 2)
├── loads                     → Discovered + scored loads
├── load_preferences          → Per-company bot targeting
├── saved_lanes               → Persistent lane searches

Broker Outreach (Phase 3)
├── brokers                   → Broker CRM
├── email_threads             → One per load+broker pair
├── email_messages            → Individual emails in thread

Booking (Phase 4)
├── bookings                  → Human-approved commitments
├── booking_approvals         → Approval audit trail

Dispatch (Phase 5)
├── dispatches                → Active load movements
├── dispatch_events           → Status change history
├── documents                 → Rate cons, BOLs, PODs

Settlement (Phase 6)
├── settlements               → Per-load financials
├── transactions              → General ledger
├── receipts                  → Uploaded + OCR'd receipts
├── receipt_line_items        → Individual line items
├── budgets                   → Monthly/category budgets
├── budget_periods            → Historical budget tracking

Analytics (Phase 6)
├── lane_analytics            → Pre-aggregated lane performance
├── broker_analytics          → Pre-aggregated broker performance

System
├── notifications             → User notification feed
├── jobs                      → Job status tracking (BullMQ mirror)
```

### Indexing Strategy
```sql
-- High-frequency load board queries
CREATE INDEX idx_loads_company_status     ON loads(company_id, status);
CREATE INDEX idx_loads_score              ON loads(company_id, ai_score DESC);
CREATE INDEX idx_loads_pickup_date        ON loads(company_id, pickup_date);
CREATE INDEX idx_loads_origin_dest        ON loads(company_id, origin_state, dest_state);

-- Email thread lookups
CREATE INDEX idx_threads_company_status   ON email_threads(company_id, status);
CREATE INDEX idx_threads_external         ON email_threads(external_thread_id);

-- Settlement / reporting
CREATE INDEX idx_settlements_company      ON settlements(company_id, status);
CREATE INDEX idx_transactions_company_dt  ON transactions(company_id, transaction_date DESC);

-- Full-text search
CREATE INDEX idx_loads_fts ON loads
  USING GIN (to_tsvector('english', origin_city || ' ' || dest_city || ' ' || commodity));
CREATE INDEX idx_brokers_fts ON brokers
  USING GIN (to_tsvector('english', name || ' ' || coalesce(company, '')));
```

### Data Retention Policy
| Table | Retention | Reason |
|---|---|---|
| loads (passed/expired) | 12 months | Lane analytics lookback |
| email_messages | 36 months | Broker relationship history |
| audit_logs | 7 years | Regulatory compliance |
| receipts (files) | 7 years | Tax records |
| notifications | 90 days | Rolling window |

---

## 4. AI Architecture

### Model Selection Matrix
| Task | Model | Reasoning |
|---|---|---|
| Load scoring | claude-haiku-4-5 | High volume (1000s/day), needs to be fast and cheap |
| Email drafting — outreach | claude-sonnet-4-20250514 | Quality matters, first impression with broker |
| Email drafting — negotiation | claude-sonnet-4-20250514 | Nuance required for rate negotiation |
| Inbound email parsing | claude-haiku-4-5 | High volume, structured extraction, speed critical |
| Receipt OCR categorization | claude-haiku-4-5 | Simple classification after Textract extracts text |
| Settlement insights | claude-sonnet-4-20250514 | Complex analysis, natural language output |
| Search intent understanding | claude-haiku-4-5 | Query expansion for load search |

### AI Prompt Architecture
```
prompts/
├── load-scoring/
│   ├── system.txt            → Scoring criteria, output schema
│   └── user.ts               → Dynamic template with load + prefs data
├── outreach/
│   ├── system.txt            → Professional freight broker tone
│   ├── first-contact.ts      → Initial outreach template
│   └── follow-up.ts          → Follow-up if no reply
├── negotiation/
│   ├── system.txt            → Negotiation strategy + floor logic
│   └── counter.ts            → Counter-offer template
├── parsing/
│   ├── inbound-email.ts      → Structured extraction schema
│   └── receipt.ts            → Receipt field extraction schema
└── insights/
    ├── system.txt            → Financial analyst persona
    └── settlement.ts         → Monthly insights template
```

### AI Output Validation
Every Claude response that produces structured data (scores, parsed emails, extracted receipt fields) is validated against a Zod schema before being written to the database. If validation fails, the job retries with a modified prompt instructing the model to fix the specific error.

### Load Scoring Model
```
Score = weighted sum of:
  rpm_score        (0-30)  → (load_rpm - market_rpm) / market_rpm * 30, capped
  deadhead_score   (0-25)  → 25 - (deadhead_miles / max_deadhead * 25)
  preference_score (0-25)  → equipment match + commodity match + lane match
  timing_score     (0-10)  → how well pickup window fits availability
  broker_score     (0-10)  → broker rating from CRM history

Total: 0-100
Threshold for auto-outreach: configurable, default 70
```

### Human Gate Implementation
```
AI Action Flow:
  1. AI produces output (email draft, negotiation reply, booking intent)
  2. Output stored with status = 'pending_human_review'
  3. Notification sent to dispatcher: "AI prepared X — review and confirm"
  4. Dispatcher sees draft in UI, can edit or approve as-is
  5. Dispatcher clicks "Confirm & Send" / "Confirm & Book"
  6. Action executes, audit log written with user_id + timestamp
  7. Status updates to 'sent' / 'booked'

No AI output ever executes without a human confirm click.
Toggle for future: auto_approve_outreach (Phase 4+, default OFF)
```

---

## 5. Email Automation Architecture

### Outbound Email Flow
```
Trigger: score-loads job produces high-scoring load
           ↓
Draft: DraftOutreachJob → Claude Sonnet → stores in email_threads
           ↓
Review: Dispatcher notified → sees draft in Outreach UI → edits if needed
           ↓
Send: "Send" click → SendEmailJob → Resend API
           ↓
Track: Resend webhook → opens, clicks, delivery events stored
```

### Inbound Email Flow
```
Broker replies → Resend inbound MX → webhook to /api/webhooks/resend
           ↓
Match: external_thread_id or subject hash → find email_thread record
           ↓
Parse: InboundEmailJob → Claude Haiku →
  { type: 'counter' | 'accept' | 'decline' | 'question' | 'info',
    rate_offered: number | null,
    message_summary: string,
    action_required: boolean }
           ↓
Route:
  accept   → create pending booking, notify dispatcher for approval
  counter  → enqueue draft-negotiation, notify dispatcher
  decline  → mark thread closed, suggest next broker
  question → notify dispatcher to reply manually
```

### Email Infrastructure
```
Sending domain options:
  Option A: Carrier's own domain (recommended)
    → Carrier configures SPF, DKIM, DMARC via Resend
    → Emails come from dispatch@theircompany.com
    → Higher deliverability, more professional
  Option B: HaulDesk subdomain
    → carrier-mc017679@dispatch.hauldesk.io
    → Zero setup for carrier
    → Good for getting started fast

Thread Management:
  → Each broker-load pair = one thread
  → In-Reply-To and References headers maintained
  → Thread reconstructed from message history on every render

Rate Limiting (outbound):
  → Max 50 outreach emails per company per day (default)
  → Max 3 follow-ups per thread
  → Minimum 24h between follow-ups
  → Configurable per company in preferences
```

---

## 6. OCR Architecture

### Pipeline
```
User uploads receipt (drag-drop / mobile camera / email forward)
           ↓
File Storage: Upload → Cloudflare R2 (original preserved)
           ↓
Job Queue: OCRJob enqueued
           ↓
Pre-processing: Sharp (Node.js)
  → Normalize to PNG if HEIC/WEBP
  → Deskew if rotated
  → Enhance contrast for faded receipts
           ↓
Text Extraction: AWS Textract
  → AnalyzeDocument with FORMS + TABLES features
  → Returns: key-value pairs, table cells, raw text blocks
  → Confidence scores per field
           ↓
AI Structuring: Claude Haiku
  → Input: Textract raw output
  → Output: structured JSON
    { merchant, date, time, subtotal, tax, tip, total,
      payment_method, category, line_items: [...],
      invoice_number, receipt_number }
           ↓
Validation: Zod schema check
  → Flag low-confidence fields for human review
  → Auto-approve if all fields ≥ 85% confidence
           ↓
Storage: Write to receipts + receipt_line_items tables
  → original_url: R2 path to original
  → processed_url: R2 path to normalized image
  → ocr_raw: Textract JSON (JSONB column)
  → ai_structured: Claude output (JSONB column)
           ↓
Review UI: If any field flagged → show editable extraction review
  → User can accept, edit, or reject individual fields
  → On approval: status = 'approved', linked to transaction
```

### Supported File Types
```
Images:  JPG, PNG, HEIC, WEBP, TIFF
Documents: PDF (single and multi-page)
Max size: 20MB per file
Bulk: Up to 50 files in one upload batch
```

### OCR Edge Cases
| Scenario | Handling |
|---|---|
| Faded / poor quality | Contrast enhancement pre-processing, lower confidence threshold triggers manual review |
| Handwritten receipts | Textract handwriting mode enabled, expected lower accuracy, always flagged for review |
| Foreign language | Textract language detection, Claude translates key fields |
| Multi-page PDF | Each page processed, results merged by Claude |
| Duplicate detection | Hash of (merchant + date + total) checked against existing receipts, flagged if match |

---

## 7. File Storage Architecture

### Provider: Cloudflare R2
Rationale: S3-compatible API (no code changes if migrating), zero egress fees (major cost difference at scale), global CDN included, Cloudflare Workers for edge transformations.

### Bucket Structure
```
hauldesk-{env}/
├── receipts/
│   └── {company_id}/
│       └── {year}/{month}/
│           ├── {receipt_id}-original.{ext}
│           └── {receipt_id}-processed.png
├── documents/
│   └── {company_id}/
│       └── {booking_id}/
│           ├── rate-con.pdf
│           ├── bol.pdf
│           └── pod.pdf
├── reports/
│   └── {company_id}/
│       └── {year}/{month}/
│           └── {report_id}.pdf
└── exports/
    └── {company_id}/
        └── {export_id}.{csv|xlsx}
```

### Access Control
```
Upload:  Presigned URL (15 min expiry) generated by backend
          → Frontend uploads directly to R2 (never through backend)
          → Backend notified via upload-complete event

Read:    Presigned URL (1 hour expiry) for sensitive docs
          → Public CDN URLs only for processed receipt thumbnails
          → All original files are private (no public access)

Delete:  Soft delete only (flag in DB, R2 file retained 90 days)
          Hard delete via background job after retention period
```

### File Processing (Cloudflare Worker)
```
On upload to receipts/ path:
  → Enqueue OCR job via API
  → Generate thumbnail (256x256) for UI preview
  → Store thumbnail at {receipt_id}-thumb.webp
```

---

## 8. Search Architecture

### Strategy: Three-tier search

**Tier 1 — Postgres Full-Text Search (FTS)**
Used for: load search, broker search, transaction search
- GIN indexes on tsvector columns
- Handles: fuzzy matching, stemming, relevance ranking
- Response time: < 50ms for most queries
- Good enough for: company-scoped searches within a single company's data

**Tier 2 — Postgres ILIKE + trigram index**
Used for: city name autocomplete, merchant name lookup
```sql
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX idx_loads_origin_trgm ON loads
  USING GIN (origin_city gin_trgm_ops);
```
- Handles: partial string matches, typos
- Response time: < 30ms

**Tier 3 — Meilisearch (when scale requires it)**
Used for: global search across all entity types, if FTS performance degrades at scale
- Deployed when: > 500k load records per tenant OR p95 search > 200ms
- Synced via: Postgres trigger → BullMQ → Meilisearch index update
- Handles: cross-entity search (loads + brokers + transactions in one query)

### Global Search Implementation
```
Search input → debounced 200ms → tRPC search.global(query)
  → Parallel queries:
      loads FTS (limit 5)
      brokers FTS (limit 5)
      transactions FTS (limit 3)
      receipts (merchant name match, limit 3)
  → Merged, ranked by relevance score
  → Results appear in < 100ms (keyboard-speed)
```

### Search Filters (Load Board)
```
Available filters (all indexed):
  origin_state, dest_state         → Enum select
  equipment_type                   → Chip multi-select
  pickup_date                      → Date range
  rate (min/max)                   → Slider
  rpm (min)                        → Input
  miles (max)                      → Slider
  deadhead_miles (max)             → Slider
  weight (max)                     → Input
  ai_score (min)                   → Slider
  status                           → Status filter
  broker_id                        → Broker dropdown

Filter state: serialized to URL params (shareable + bookmarkable)
```

---

## 9. Deployment Architecture

### Infrastructure Topology
```
                    ┌─────────────────────────────┐
                    │       Cloudflare CDN         │
                    │   (DDoS, WAF, caching)       │
                    └──────────────┬──────────────┘
                                   │
              ┌────────────────────┴────────────────────┐
              │                                          │
     ┌────────▼───────┐                      ┌──────────▼──────────┐
     │ Vercel         │                      │ Railway             │
     │ (Frontend)     │                      │ (Backend)           │
     │                │                      │                     │
     │ Next.js 14     │◄────── tRPC ────────►│ ┌─────────────────┐│
     │ Edge Network   │                      │ │ API Server      ││
     │ 50+ regions    │                      │ │ (Node.js)       ││
     └────────────────┘                      │ └────────┬────────┘│
                                             │          │         │
                                             │ ┌────────▼────────┐│
                                             │ │ Queue Workers   ││
                                             │ │ (BullMQ)        ││
                                             │ └─────────────────┘│
                                             └──────────┬──────────┘
                                                        │
                    ┌───────────────────────────────────┼────────────────────────┐
                    │                                   │                        │
           ┌────────▼────────┐              ┌───────────▼──────┐    ┌────────────▼──────┐
           │ Supabase        │              │ Upstash          │    │ Cloudflare R2     │
           │ (PostgreSQL 16) │              │ (Redis)          │    │ (Object Storage)  │
           │ + Realtime      │              │ BullMQ queues    │    │ Files, receipts   │
           │ + Auth helper   │              │ Rate limiting    │    │ Documents, exports│
           └─────────────────┘              │ Session cache    │    └───────────────────┘
                                            └──────────────────┘
```

### Environment Strategy
```
development  → Local Next.js + local Postgres (Docker)
staging      → Full cloud stack, separate DB, anonymized data
production   → Full cloud stack, RLS enabled, monitoring active
```

### CI/CD Pipeline
```
GitHub → Push to main branch
  ↓
GitHub Actions:
  1. TypeScript type check (tsc --noEmit)
  2. ESLint
  3. Unit tests (Vitest)
  4. Integration tests (against staging DB)
  5. Build Next.js (vercel build)
  ↓
Vercel: Auto-deploy frontend (preview for PRs, prod for main)
Railway: Auto-deploy backend container (zero-downtime rolling deploy)
  ↓
Post-deploy:
  Supabase: Run Prisma migrations
  Sentry: Create release marker
  Upstash: Flush stale queue keys if schema changed
```

### Scaling Approach
```
Traffic tiers:
  0-100 companies:    Current architecture handles comfortably
  100-1000 companies: Add Railway horizontal scaling (2-4 API replicas)
  1000+ companies:    Shard queue workers by company_id range
                      Add read replicas for analytics queries
                      Consider dedicated Meilisearch cluster

Load polling at scale:
  Each company = 1 recurring BullMQ job
  1000 companies × 15-min interval = ~67 polls/min
  DAT API rate limit: typically 60 req/min per credential
  Solution: DAT Enterprise plan or multiple API credentials
             Stagger job scheduling to spread over the window
```

---

## 10. Security Architecture

### Authentication (Clerk)
```
Session: Short-lived JWTs (15 min), refresh tokens (30 days)
MFA: TOTP (Google Authenticator / Authy) — available, owner can enforce
SSO: SAML / Google Workspace for enterprise plan
Session revocation: Real-time via Clerk webhook → invalidate Redis cache
Password policy: Clerk enforced — min 12 chars, breach detection
```

### Authorization — Three Layers
```
Layer 1 — Clerk JWT (HTTP level)
  → Every request must carry valid JWT
  → Expired or invalid = 401, no DB hit

Layer 2 — tRPC Middleware (Application level)
  → Role check per procedure
  → company_id extracted from JWT claims
  → Owner > Admin > Dispatcher > Driver > Viewer
  → Procedure-level: e.g. only Owner can approve bookings

Layer 3 — Postgres RLS (Database level)
  → Policy: company_id = current_setting('app.company_id')
  → Even if Layer 2 is bypassed, queries return no data
  → Migrations tested: new tables must have RLS policy or deploy fails

Role Permission Matrix:
  Procedure              Owner  Admin  Dispatcher  Driver  Viewer
  loads.search             ✓      ✓        ✓
  loads.pass               ✓      ✓        ✓
  bookings.approve         ✓      ✓
  bookings.create          ✓      ✓        ✓
  outreach.send            ✓      ✓        ✓
  settlements.update       ✓      ✓
  users.invite             ✓      ✓
  billing.manage           ✓
  audit.view               ✓      ✓
  receipts.upload          ✓      ✓        ✓         ✓
  loads.view               ✓      ✓        ✓         ✓       ✓
  reports.view             ✓      ✓        ✓                 ✓
```

### Data Security
```
Encryption at rest:
  → Supabase: AES-256 at database level
  → Cloudflare R2: AES-256 server-side encryption
  → Sensitive fields (email addresses, phone numbers):
      encrypted at application level with AES-256-GCM
      key stored in Vercel environment (not in DB)

Encryption in transit:
  → TLS 1.3 enforced everywhere
  → HSTS with preload
  → Certificate pinning for mobile (future)

Secrets management:
  → Never in code or version control
  → Vercel Environment Variables (encrypted, per-environment)
  → Rotated quarterly: DAT API, Truckstop API, Resend, R2 keys
  → Anthropic API key: server-side only, never exposed to client
```

### API Security
```
Rate limiting (Upstash Redis):
  → Unauthenticated: 20 req/min per IP
  → Authenticated: 300 req/min per user
  → AI endpoints: 60 req/min per company (cost control)
  → Webhook endpoints: 500 req/min per source IP

Input validation:
  → Zod schemas on every tRPC input
  → File upload: MIME type + magic byte validation (not just extension)
  → Max request body: 25MB (file uploads via presigned URL bypass this)

OWASP Top 10 coverage:
  A01 Broken Access Control     → RLS + role middleware
  A02 Cryptographic Failures    → AES-256 + TLS 1.3
  A03 Injection                 → Prisma parameterized queries (no raw SQL)
  A04 Insecure Design           → Human gate on all financial actions
  A05 Security Misconfiguration → Infra-as-code, no manual server config
  A06 Vulnerable Components     → Dependabot + monthly audit
  A07 Auth Failures             → Clerk handles, brute-force protection built in
  A08 Software/Data Integrity   → Signed deployments, Zod validation
  A09 Logging Failures          → Audit log on every mutation, Sentry errors
  A10 SSRF                      → Allowlist for external HTTP calls (DAT, Truckstop, Resend only)
```

### Audit Trail
```
Every mutation writes to audit_logs:
  {
    company_id, user_id, action,
    entity_type, entity_id,
    before_data (JSONB snapshot),
    after_data (JSONB snapshot),
    ip_address, user_agent,
    created_at (immutable)
  }

Immutability: No UPDATE or DELETE on audit_logs (Postgres policy)
Retention: 7 years
Access: Owner + Admin only
Export: CSV download for compliance
```

---

## Technology Recommendation Summary

| Domain | Technology | Tier |
|---|---|---|
| **Frontend framework** | Next.js 14 (App Router) | Core |
| **Frontend language** | TypeScript | Core |
| **Styling** | Tailwind CSS | Core |
| **Component library** | Radix UI | Core |
| **State — server** | TanStack Query | Core |
| **State — client** | Zustand | Core |
| **Forms + validation** | React Hook Form + Zod | Core |
| **Tables** | TanStack Table | Core |
| **Charts** | Recharts | Core |
| **Backend framework** | Node.js + tRPC | Core |
| **ORM** | Prisma | Core |
| **Database** | PostgreSQL 16 (Supabase) | Core |
| **Realtime** | Supabase Realtime | Core |
| **Authentication** | Clerk | Core |
| **Job queue** | BullMQ | Core |
| **Cache + rate limit** | Upstash Redis | Core |
| **AI / LLM** | Anthropic Claude (Haiku + Sonnet) | Core |
| **Email delivery** | Resend | Core |
| **OCR text extraction** | AWS Textract | Core |
| **OCR structuring** | Claude Haiku (post-Textract) | Core |
| **File storage** | Cloudflare R2 | Core |
| **Load data — primary** | DAT Connect API | Core |
| **Load data — secondary** | Truckstop API | Secondary |
| **Search — primary** | Postgres FTS + trigrams | Core |
| **Search — at scale** | Meilisearch | When needed |
| **Frontend hosting** | Vercel | Core |
| **Backend hosting** | Railway | Core |
| **CDN + WAF** | Cloudflare | Core |
| **Monitoring** | Sentry | Core |
| **Analytics** | Vercel Analytics | Core |
| **PDF generation** | Puppeteer (Railway) | Core |
| **Image processing** | Sharp (Node.js) | Core |
| **CI/CD** | GitHub Actions | Core |
| **Billing** | Stripe | Phase 7 |

---

## Platform Scale Targets

| Metric | Target | Architecture supports |
|---|---|---|
| Concurrent users | 5,000 | Vercel edge + stateless API |
| Loads in DB | 10M+ | Postgres partitioning by date |
| Brokers in CRM | 100,000+ | Indexed, paginated |
| Email threads | 1M+ | Archived after 90 days active |
| Loads discovered/day | 50,000+ | BullMQ workers + rate limit management |
| OCR jobs/day | 10,000+ | AWS Textract scales infinitely |
| API response p95 | < 200ms | Indexed queries + connection pooling |
| Real-time latency | < 500ms | Supabase Realtime WebSocket |
| File upload | < 5s per file | Direct-to-R2 presigned URL |
| Search results | < 100ms | GIN indexes + trigrams |

---

*This document governs all phases. Changes to core architecture decisions require review before any phase build begins.*

*Phase 1 complete. Awaiting approval for Phase 2 — Load Discovery & Board.*
