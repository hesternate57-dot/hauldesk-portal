# HaulDesk — Phase 19: Notifications & Audit Logs
**Version:** 1.0 | **Phase:** 19 of 21

---

## 1. Notification System

### Notification Types
| Type | Trigger | Priority | Icon |
|---|---|---|---|
| booking_approval | AI prepared booking awaiting confirm | Urgent | ✅ |
| broker_reply | Broker replied to outreach | High | 💬 |
| outreach_sent | AI sent email to broker | Normal | 📧 |
| negotiation_update | Counter-offer received or accepted | High | 🤝 |
| dispatch_status | Driver status update | Normal | 🗺️ |
| dispatch_delay | Load running late | High | ⚠️ |
| settlement_created | Load delivered, settlement ready | Normal | 💰 |
| payment_received | Invoice paid | Normal | ✅ |
| ocr_complete | Receipt processed, needs review | Normal | 🧾 |
| ai_insight | New savings opportunity found | Low | ✨ |
| budget_warning | Spending approaching limit | High | 🎯 |
| team_invite | Team member accepted invite | Normal | 👥 |
| system | Platform alert or update | Low | ⚙️ |

### Notification Feed
- Stored in `notifications` table (Phase 2 schema)
- Real-time via Supabase Realtime WebSocket subscription
- Grouped by: All / Unread / Urgent / By Category
- Mark single read / Mark all read
- Click notification → navigate to relevant screen

---

## 2. Audit Log System

### Action Categories
```
🔐 Auth      → login, logout, MFA setup, password change
📋 Bookings  → create, approve, cancel, TONU
🚚 Loads     → discovered, scored, passed, expired
📧 Outreach  → draft created, email sent, reply received
💬 Negotiate → counter offered, accepted, declined
🗺 Dispatch  → assigned, status updated, delivered
💰 Finance   → settlement created, invoice sent, payment
🤖 AI        → load scored, email drafted, insight generated
👤 Team      → user invited, role changed, deactivated
🧾 Documents → uploaded, OCR processed, approved, rejected
⚙️ System    → preferences updated, lane saved, export
```

### Audit Record Structure
```json
{
  "id": "uuid",
  "company_id": "uuid",
  "user_id": "uuid | null (system/AI)",
  "actor": "Nate Brokerage | AI System | HaulDesk Bot",
  "action": "bookings.approve",
  "entity_type": "bookings",
  "entity_id": "uuid",
  "description": "Approved booking #1042 — Houston → Van Buren at $1,600",
  "before_data": {},
  "after_data": {},
  "ip_address": "192.168.1.1",
  "created_at": "2025-05-04T09:31:00Z"
}
```

### Immutability
- `audit_logs` table has no UPDATE or DELETE rules (Phase 2 spec)
- Retention: 7 years (regulatory compliance)
- Export: CSV for accounting/legal review

---

## 3. Screen Specifications

### Notifications Screen
```
┌──────────────────────────────────────────────────────┐
│ Notifications          [Mark all read] [Settings]    │
│ 3 unread · 12 today · 47 this week                   │
├──────────────────────────────────────────────────────┤
│ [All] [Unread 3] [Bookings] [Outreach] [Dispatch]   │
│ [Settlements] [AI Insights]                          │
├──────────────────────────────────────────────────────┤
│ ● ✅ Booking ready for approval  2m ago   [Approve]  │
│ ● 💬 Broker reply — TFSL        14m ago   [View]    │
│   🧾 OCR complete — 3 receipts   1h ago   [Review]  │
│   ✨ AI insight: fuel savings     3h ago   [View]    │
│   💰 Payment received — TFSL      2d ago   [View]    │
└──────────────────────────────────────────────────────┘
```

### Audit Log Screen
```
┌──────────────────────────────────────────────────────┐
│ Audit Log            [Export CSV] [Date Range ▾]     │
│ 1,247 total entries · 7-year retention               │
├──────────────────────────────────────────────────────┤
│ [Filter: All] [Auth] [Bookings] [AI] [User] [Search] │
├──────────────────────────────────────────────────────┤
│ 09:31 AM  Nate    ✅ Approved booking #1042          │
│           Houston → Van Buren · $1,600               │
│                                                      │
│ 09:22 AM  AI Bot  🤖 Load scored: 94/100             │
│           Load #1042 · Houston → Van Buren           │
│                                                      │
│ 09:14 AM  System  📧 Outreach email sent             │
│           TFSL Logistics · Van Buren run             │
└──────────────────────────────────────────────────────┘
```

---

## 4. API Endpoints

```
notifications.list(filter, page)    → Paginated feed
notifications.markRead(id)          → Single mark read
notifications.markAllRead()         → Bulk mark read
notifications.getUnreadCount()      → Badge count
notifications.updatePrefs(prefs)    → Notification settings

audit.list(filters, page)           → Paginated audit log
audit.get(id)                       → Single entry + diff
audit.export(filters)               → CSV download URL
audit.getStats()                    → Action counts by type
```

*Phase 19 complete — notifications and audit log integrated in portal.*
