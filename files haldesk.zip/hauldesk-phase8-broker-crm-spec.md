# HaulDesk — Phase 8: Broker CRM
**Version:** 1.0 | **Phase:** 8 of 21

---

## 1. Overview

The Broker CRM is the relationship layer of HaulDesk. Every broker the AI contacts, every rate negotiated, every load booked traces back to a broker record. The CRM makes those relationships visible, scoreable, and actionable.

A "good broker" is not just one who pays well — it's one who responds fast, negotiates fairly, pays on time, and books repeatedly. The scorecard surfaces all of this at a glance.

---

## 2. Data Model (extends Phase 2 schema)

### brokers table (core fields tracked in CRM)
```
id, company_id, name, legal_name, mc_number, dot_number
primary_email, primary_phone, website
address, city, state, zip
rating (0–5), credit_score (0–100)
total_loads, total_revenue
avg_rate, avg_rate_per_mile
response_rate (%), booking_rate (%)
avg_days_to_pay, credit_limit
preferred (bool), blocked (bool)
tags (text[]), notes
source (manual | dat | truckstop | email)
created_at, updated_at
```

### broker_contacts table
```
id, broker_id, name, title, email, phone, phone_ext
preferred_channel, is_primary, last_contacted_at, notes
```

### Computed scorecard fields (derived, not stored)
```
response_score   = response_rate mapped 0–25
rate_score       = (avg_rpm / market_rpm) * 25, capped at 25
pay_speed_score  = (30 - avg_days_to_pay) / 30 * 25, min 0
booking_score    = booking_rate * 25
overall_score    = sum of above, 0–100
```

---

## 3. Screen Architecture

```
┌────────────────────────────────────────────────────────┐
│  Broker CRM                          [+ Add Broker]    │
├────────────────────────────────────────────────────────┤
│  [Search…] [Status▾] [Equipment▾] [Rating▾] [Sort▾]  │
├────────────────────────────────────────────────────────┤
│  STATS: 247 brokers · 18 preferred · 82% avg response  │
├────────────────────────────────────────────────────────┤
│  BROKER TABLE                                          │
│  Broker | MC# | Score | Avg$/mi | Response | Revenue  │
│  ─────────────────────────────────────────────────────│
│  TFSL Logistics   [★92] $3.42  87%  3.1d  $28,400 [→]│
│  Cardinal Freight [★84] $3.18  74%  5.2d  $14,200 [→]│
│  Gulf Star        [★71] $2.94  52%  8.1d  $ 8,900 [→]│
│  ...                                                   │
├────────────────────────────────────────────────────────┤
│  [Showing 1–20 of 247]  [← Prev] [Next →]             │
└────────────────────────────────────────────────────────┘

BROKER PROFILE DRAWER (right slide-in, 580px):
├── Header: avatar, name, company, MC#, status tags
├── [Overview] [Communications] [Load History] [Notes]
│
├── Overview Tab:
│   ├── Scorecard (overall + 4 sub-scores)
│   ├── Performance grid (6 key metrics)
│   ├── Primary contact card
│   └── Quick actions (Email, Add Note, Block)
│
├── Communications Tab:
│   └── Email thread list (from email_conversations)
│
├── Load History Tab:
│   └── All loads booked with this broker
│
└── Notes Tab:
    └── Free-form notes + tags
```

---

## 4. Scorecard Specification

### Overall Score (0–100)
```
Response Score   0–25   response_rate mapped linearly
Rate Score       0–25   avg_rpm vs DAT market rpm
Pay Speed Score  0–25   days_to_pay (30d = 0, 0d = 25)
Booking Score    0–25   booking_rate mapped linearly
```

### Score Tiers
| Score | Label | Color |
|---|---|---|
| 90–100 | ELITE | Teal |
| 75–89 | PREFERRED | Blue |
| 60–74 | STANDARD | Neutral |
| 40–59 | MONITOR | Amber |
| 0–39 | AT RISK | Red |

---

## 5. Relationship Status

| Status | Description | Action |
|---|---|---|
| **Preferred** | High-score brokers, priority outreach | Green badge |
| **Active** | Regular interaction, good standing | Default |
| **Prospect** | Added, not yet contacted | Gray |
| **Inactive** | No activity 90+ days | Amber |
| **Blocked** | Do not contact | Red |

---

## 6. Communication History

Each row shows:
- Load route + rate offered
- Direction (outbound initiated / inbound)
- Status (sent / replied / negotiating / booked / declined)
- Outcome rate
- Date

---

## 7. API Endpoints

```
brokers.list(filters, sort, page)    → Paginated broker list
brokers.get(id)                      → Full broker with computed scores
brokers.create(data)                 → Add new broker
brokers.update(id, data)             → Edit broker
brokers.getScorecard(id)             → Computed scorecard breakdown
brokers.getContacts(id)              → All contacts for broker
brokers.getCommunications(id)        → Email thread history
brokers.getLoadHistory(id)           → All loads with this broker
brokers.setPreferred(id, bool)       → Toggle preferred status
brokers.setBlocked(id, bool)         → Toggle blocked status
brokers.addNote(id, note)            → Append note
```

*Phase 8 complete — spec delivered. Screens integrated in portal.*
