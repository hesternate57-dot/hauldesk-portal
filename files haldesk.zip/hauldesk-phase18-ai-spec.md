# HaulDesk — Phase 18: AI Operations Assistant
**Version:** 1.0 | **Phase:** 18 of 21

---

## 1. Purpose

The AI Operations Assistant is a conversational copilot built directly into HaulDesk. It has full context of the carrier's operation — loads, brokers, lanes, drivers, financials — and can answer questions, surface insights, and recommend actions in plain English.

Unlike generic chatbots, this assistant:
- Knows your specific data (loads, brokers, lanes, expenses)
- Speaks freight (RPM, deadhead, rate con, TONU, BOL, factoring)
- Gives specific, actionable answers with real numbers
- Remembers the conversation context to handle follow-ups

---

## 2. Architecture

```
User message
  → Frontend: append to conversation history
  → Anthropic Claude API (claude-sonnet)
      System prompt: company context + live data snapshot
      Messages: full conversation history
  → Response streamed back token by token
  → Rendered in chat with formatted insight cards
  → Suggested follow-ups generated per response
```

### System Prompt Structure
```
You are HaulDesk AI, a freight operations expert for {company}.

COMPANY CONTEXT:
  MC: {mc_number} | DOT: {dot_number}
  Equipment: {truck_types}
  Drivers: {driver_names}
  Home base: {home_city}

CURRENT OPERATION (live snapshot):
  Loads available today: {count} on {lanes}
  Loads in transit: {active_dispatches}
  Pending approvals: {booking_approvals}
  MTD revenue: {gross} gross / {net} net
  Avg RPM (7d): {rpm}
  Top broker: {broker} at {response_rate}% response

FINANCIAL CONTEXT:
  Fuel spend MTD: {fuel}
  Broker fees MTD: {fees}
  Net margin: {margin}%

BEHAVIORAL RULES:
  - Answer with specific numbers from the context
  - Give actionable recommendations, not just descriptions
  - Keep responses focused (3-5 key points max)
  - Flag risks or issues proactively
  - Use freight industry terminology correctly
  - Format key data as bullet points for readability
```

---

## 3. Chat Interface

### Suggested Prompts (shown before first message)
```
Grid of 8 prompts organized by category:

TODAY'S OPERATION:
  "Which loads should I pursue today?"
  "What's my most urgent action right now?"

PERFORMANCE:
  "Which loads are most profitable?"
  "What lanes generate the highest margins?"

RELATIONSHIPS:
  "Which brokers respond fastest?"
  "Which broker should I prioritize for outreach?"

FINANCIALS:
  "Where am I losing money?"
  "How is my fuel spending trending?"
```

### Message Types

**User message** — right-aligned, teal background

**AI response** — left-aligned, card style, may include:
- Text explanation
- Data table (markdown → HTML table)
- Insight bullets (● key points)
- Recommendation block (🎯 action to take)
- Warning block (⚠ risk to watch)

**Suggested follow-ups** — shown below each AI response as clickable chips

**Insight cards** — proactively surfaced when AI detects an important finding

---

## 4. Response Formatting

The AI returns structured responses:

```
[Text answer with context]

● Key finding 1
● Key finding 2
● Key finding 3

🎯 Recommended action: [specific action]

⚠ Watch out: [risk if applicable]
```

The frontend parses this format and renders:
- Bullets as styled list items
- 🎯 blocks as a teal recommendation card
- ⚠ blocks as an amber warning card
- Numbers in bold

---

## 5. Context Refresh

The system prompt is rebuilt on each message using:
- Current dashboard KPIs (polled every 60s)
- Active load count and top matches
- MTD financials
- Last 5 broker interactions

This ensures the AI always answers with fresh operational data.

---

## 6. Conversation Memory

Full conversation history sent on every API call (up to 20 turns, then oldest pruned). The AI can reference prior messages:

> User: "Which broker pays fastest?"
> AI: "TFSL at 3.1 days avg..."
> User: "How many loads have we done with them?"
> AI: [knows to look up TFSL from prior context]

---

*Phase 18 complete — live AI copilot integrated in portal.*
