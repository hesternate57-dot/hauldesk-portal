# HaulDesk — Phase 17: Analytics Center
**Version:** 1.0 | **Phase:** 17 of 21

---

## 1. Dashboard Overview

Seven analytics modules unified under one screen. Each module answers a specific operational question:

| Module | Core Question |
|---|---|
| **Revenue Trends** | Are we making more money over time? |
| **RPM Trends** | Are we charging the right rate per mile? |
| **Broker Performance** | Which brokers pay best and respond fastest? |
| **Lane Performance** | Which routes are most profitable? |
| **Driver Performance** | Who's generating the most revenue? |
| **Profitability** | Where does the money go after expenses? |
| **Settlement Analysis** | How fast are we getting paid? |

---

## 2. Data Sources (tRPC)

```
analytics.getRevenueTrends(period, groupBy)   → time series: gross, net, loads
analytics.getRPMTrends(period, groupBy)        → time series: avg rpm, market rpm
analytics.getBrokerPerformance(period, limit)  → ranked broker stats
analytics.getLanePerformance(period, limit)    → ranked lane stats
analytics.getDriverPerformance(period)         → per-driver stats
analytics.getProfitability(period)             → cost breakdown, margin
analytics.getSettlementAnalysis(period)        → payment timing, outstanding
```

All endpoints accept: `period` (7d | 30d | 90d | 365d | custom) and return pre-aggregated data.

---

## 3. Module Specifications

### Revenue Trends
- **Primary chart:** Dual-line (gross + net), daily/weekly/monthly toggle
- **KPIs:** Total gross, total net, avg per load, load count
- **Secondary:** Bar chart — revenue by equipment type (reefer, dry van, flatbed)
- **Table:** Month-by-month comparison

### RPM Trends
- **Primary chart:** Line — avg $/mi vs DAT market rate (reference line)
- **KPIs:** Avg RPM, vs market, best day, worst day
- **Secondary:** Lane-level RPM scatter (simplified as bar chart)

### Broker Performance
- **Primary chart:** Horizontal bar — revenue per broker (top 10)
- **KPIs:** Top broker, avg response rate, avg days to pay, total brokers used
- **Table:** Full broker scorecard (revenue, loads, RPM, response, booking, pay speed)
- **Sort:** By revenue | loads | RPM | response rate | days to pay

### Lane Performance
- **Primary chart:** Horizontal bar — net $/mi per lane (top 10 lanes)
- **KPIs:** Best lane, worst lane, avg lane RPM, total lane-miles
- **Table:** Lane detail (route, loads, gross, net, avg RPM, avg miles, deadhead avg)

### Driver Performance
- **Primary chart:** Bar — loads completed per driver
- **Secondary chart:** Bar — gross revenue attributed per driver
- **KPIs:** Top driver, avg loads/driver, avg revenue/driver, fleet utilization %
- **Table:** Driver detail (name, loads, miles, gross revenue, on-time %)

### Profitability
- **Primary chart:** Stacked bar — gross vs deductions vs net per week
- **Secondary chart:** Doughnut — expense breakdown (fuel, broker fees, maintenance, etc.)
- **KPIs:** Total gross, total deductions, net margin %, net per load avg
- **Table:** Cost category breakdown with month-over-month change

### Settlement Analysis
- **Primary chart:** Bar — days to payment per broker
- **Secondary chart:** Line — outstanding invoice balance over time
- **KPIs:** Avg days to pay, outstanding total, paid this month, factored %
- **Table:** Outstanding invoices with aging (0-30, 31-60, 60+ days)

---

## 4. Date Range Controls

```
[This Week] [This Month] [Last 3 Mo] [Last 12 Mo] [Custom: from — to]
```

Changing range re-fetches all charts for the current module.

---

## 5. Export Options

Per module:
- Export CSV (raw data)
- Export PDF (chart + table snapshot)
- Share link (URL with module + date range params)

*Phase 17 complete — all analytics dashboards integrated in portal.*
