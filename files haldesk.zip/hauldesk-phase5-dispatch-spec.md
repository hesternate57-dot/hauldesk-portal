# HaulDesk — Phase 5: Dispatch Command Center
**Version:** 1.0 | **Phase:** 5 of 21

---

## 1. Purpose

The Dispatch Command Center is the operational nerve center of HaulDesk. It answers the single question a dispatcher asks every morning: **"Where do I stand right now, and what needs my attention?"**

Every metric, widget, and feed is scoped to the current day unless otherwise noted. All KPIs are live-calculated and refresh every 60 seconds (Supabase Realtime subscriptions for critical fields, polling for aggregates).

---

## 2. KPI Card Specifications

### Row 1 — Core Operations
| Card | Value | Trend | Sub-label | Color |
|---|---|---|---|---|
| **Loads Available** | Count of active `loads` in `discovered\|scored` status | vs yesterday | "on N active lanes" | Neutral |
| **Loads Contacted** | Count of `email_conversations` sent today | vs yesterday | "AI outreach sent today" | Blue |
| **Loads Booked** | Count of `bookings` with `approved` status, MTD | vs last MTD | "MTD gross revenue" | Teal |
| **Revenue Forecast** | SUM(rate_confirmed) projected to month-end | vs last month | "projected net MTD" | Teal |
| **Average RPM** | AVG(rpm) on booked loads, rolling 7d | vs lane average | "7-day rolling" | Teal |

### Row 2 — Performance Indicators
| Card | Value | Trend | Sub-label | Color |
|---|---|---|---|---|
| **Deadhead Avg** | AVG(deadhead_miles) on dispatches, rolling 7d | vs prev 7d | "lower is better" | Neutral/Amber |
| **Broker Responses** | Count of `email_conversations` with status `replied` today | as % of sent | "X% response rate" | Blue |
| **Pending Follow Ups** | Count of conversations `sent` > 24h with no reply | urgency color | "need attention" | Amber/Red |
| **Booked Today** | Count of `bookings.approved_at` = today | gross value | "today's commits" | Teal |
| **Drivers Active** | Count of `drivers.status = 'driving'` / total | available count | "N available now" | Neutral |

---

## 3. Widget Specifications

### 3.1 AI Outreach Activity
**Type:** Line chart (Chart.js) + stat row  
**Data:** `email_conversations` grouped by day, last 14 days  
**Series:**
- Outreach Sent (teal line)
- Replies Received (dashed amber line)
- Bookings Converted (teal area fill)

**Stat row below chart:**
- Emails sent today | Reply rate | Avg response time | Best performing lane

**Size:** 2/3 width, 280px height

---

### 3.2 Broker Responses
**Type:** List  
**Data:** Last 10 `email_conversations` ordered by `updated_at DESC`  
**Each row:**
- Broker name + company
- Load route (short)
- Status badge (replied / pending / negotiating / accepted / declined)
- Time since last activity
- Quick action: Reply | View Thread

**Size:** 1/3 width

---

### 3.3 Booking Funnel
**Type:** Custom horizontal funnel visualization  
**Stages:**
```
Loads Discovered   ████████████████████████ 28  (100%)
Loads Contacted    ████████████████         14  (50%)
Broker Replied     █████████                 8  (57% of contacted)
Negotiating        ██████                    5  (63% of replied)
Booked             ████                      3  (60% of negotiating)
```
**Conversion rates shown between each stage**  
**Color:** gradient from lighter to full teal as funnel narrows  
**Size:** 1/2 width

---

### 3.4 Settlement Forecast
**Type:** Grouped bar chart (Chart.js)  
**Data:** Per-week: gross revenue vs net revenue for current month  
**Additional line:** Month target overlay  
**Stat row:** Month-to-date net | Projected net | vs target  
**Size:** 1/2 width

---

### 3.5 Recent Activity Feed
**Type:** Chronological event feed  
**Data:** Mix of:
- `audit_logs` for booking/dispatch events
- `email_messages` for broker comms
- `notifications` for system events

**Event types with icons:**
```
🚚  Load discovered and scored
📧  Outreach sent to broker
💬  Broker replied (rate offered)
✅  Booking confirmed by user
🗺️  Driver status updated
💰  Payment received
🧾  Receipt uploaded + OCR'd
⚠️  Budget warning
✨  AI insight generated
```
**Size:** Spans full bottom row, 3 columns feed

---

## 4. Layout

```
┌─────────────────────────────────────────────────────────────┐
│  COMMAND CENTER — Good morning, Nate  [Live: 2s ago ●]      │
├──────────────┬──────────────┬──────────────┬───────────┬────┤
│ Loads        │ Contacted    │ Booked       │ Revenue   │ RPM│
│ Available    │ Today        │ MTD          │ Forecast  │Avg │
│    28        │    14        │    6         │ $24,180   │$2.94│
├──────────────┼──────────────┼──────────────┼───────────┼────┤
│ Deadhead     │ Broker       │ Pending      │ Booked    │Drv │
│ Avg 14 mi    │ Responses 8  │ Follow Up 3  │ Today 2   │Act │
├──────────────────────────────────────────┬──────────────────┤
│                                          │                  │
│    AI OUTREACH ACTIVITY (chart)          │ BROKER RESPONSES │
│    [14d line: sent vs replies vs booked] │ [list w/ status] │
│    Sent 14 | Rate 57% | Avg 4.2h        │                  │
├──────────────────────┬───────────────────┘                  │
│                      │                                      │
│  BOOKING FUNNEL      │   SETTLEMENT FORECAST (chart)        │
│  [custom funnel viz] │   [weekly gross vs net bars]         │
│                      │                                      │
├──────────────────────┴──────────────────────────────────────┤
│                  RECENT ACTIVITY FEED                       │
│  [live event stream — loads, emails, bookings, dispatch]    │
└─────────────────────────────────────────────────────────────┘
```

---

## 5. Real-Time Updates

| Component | Update method | Frequency |
|---|---|---|
| KPI cards | Supabase Realtime (loads, bookings) | Instant |
| Broker responses | Supabase Realtime (email_conversations) | Instant |
| Activity feed | Supabase Realtime (notifications) | Instant |
| Charts | Polling | Every 60s |
| Revenue forecast | Computed on-demand | On navigation |

---

## 6. API Endpoints (tRPC)

```
dashboard.getKPIs()              → All 10 KPI values + trends
dashboard.getOutreachActivity()  → 14-day outreach time series
dashboard.getBrokerResponses()   → Last 10 conversation summaries
dashboard.getBookingFunnel()     → Funnel stage counts + rates
dashboard.getSettlementForecast()→ Weekly gross/net + projection
dashboard.getActivityFeed(limit) → Mixed event stream, paginated
```

---

*Phase 5 Complete — operational command center specified and integrated.*
