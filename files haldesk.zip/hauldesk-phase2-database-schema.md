# HaulDesk — Phase 2: Complete Database Schema
**Version:** 1.0 | **Engine:** PostgreSQL 16 | **ORM:** Prisma

---

## Domain Overview

| Domain | Tables |
|---|---|
| Identity & Access | users, roles, permissions, role_permissions |
| Fleet | drivers, trucks, equipment_types |
| Load Discovery | loads, load_matches, load_preferences, saved_lanes |
| Broker Management | brokers, broker_contacts |
| Outreach | email_conversations, email_messages |
| Negotiation & Booking | negotiations, bookings, carrier_packets, rate_confirmations |
| Operations | dispatches, dispatch_events |
| Finance | settlements, transactions, receipts, receipt_line_items |
| Intelligence | ai_insights, ocr_results |
| System | notifications, audit_logs, documents |

---

## Extensions Required

```sql
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";
CREATE EXTENSION IF NOT EXISTS "btree_gin";
```

---

## Domain 1 — Identity & Access

### companies
```sql
CREATE TABLE companies (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name              TEXT        NOT NULL,
  mc_number         TEXT        UNIQUE,
  dot_number        TEXT        UNIQUE,
  address_line1     TEXT,
  address_line2     TEXT,
  city              TEXT,
  state             CHAR(2),
  zip               TEXT,
  phone             TEXT,
  email             TEXT,
  website           TEXT,
  logo_url          TEXT,
  plan              TEXT        NOT NULL DEFAULT 'starter'
                    CHECK (plan IN ('starter','growth','pro','enterprise')),
  plan_seats        INT         NOT NULL DEFAULT 3,
  status            TEXT        NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','suspended','cancelled')),
  onboarded_at      TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE UNIQUE INDEX idx_companies_mc   ON companies(mc_number) WHERE mc_number IS NOT NULL;
CREATE UNIQUE INDEX idx_companies_dot  ON companies(dot_number) WHERE dot_number IS NOT NULL;
```

---

### roles
```sql
CREATE TABLE roles (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        REFERENCES companies(id) ON DELETE CASCADE,
  name              TEXT        NOT NULL,
  description       TEXT,
  is_system         BOOLEAN     NOT NULL DEFAULT FALSE,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (company_id, name)
);
```
**Seed data (system roles):**
```sql
-- owner, admin, dispatcher, driver, viewer
-- is_system = TRUE, company_id = NULL (global defaults)
```
**Indexes:**
```sql
CREATE INDEX idx_roles_company ON roles(company_id);
```

---

### permissions
```sql
CREATE TABLE permissions (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  resource          TEXT        NOT NULL,
  action            TEXT        NOT NULL,
  description       TEXT,
  UNIQUE (resource, action)
);
```
**Example seed data:**
```
loads.view | loads.create | loads.pass | loads.score
bookings.view | bookings.create | bookings.approve
outreach.view | outreach.send
settlements.view | settlements.update
users.invite | users.manage
billing.manage
audit.view
```

---

### role_permissions
```sql
CREATE TABLE role_permissions (
  role_id           UUID        NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id     UUID        NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);
```
**Indexes:**
```sql
CREATE INDEX idx_role_perms_role ON role_permissions(role_id);
```

---

### users
```sql
CREATE TABLE users (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  role_id           UUID        NOT NULL REFERENCES roles(id),
  clerk_id          TEXT        UNIQUE NOT NULL,
  email             TEXT        NOT NULL,
  name              TEXT        NOT NULL,
  phone             TEXT,
  avatar_url        TEXT,
  status            TEXT        NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','invited','suspended','deactivated')),
  last_active_at    TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_users_company      ON users(company_id);
CREATE INDEX idx_users_role         ON users(role_id);
CREATE UNIQUE INDEX idx_users_clerk ON users(clerk_id);
CREATE UNIQUE INDEX idx_users_email_company ON users(company_id, email);
```

---

## Domain 2 — Fleet

### equipment_types
```sql
CREATE TABLE equipment_types (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  name              TEXT        NOT NULL UNIQUE,
  category          TEXT        NOT NULL
                    CHECK (category IN ('dry','temperature','flatbed','specialized','other')),
  temp_controlled   BOOLEAN     NOT NULL DEFAULT FALSE,
  max_weight_lbs    INT,
  max_length_ft     INT,
  description       TEXT
);
```
**Seed data:**
```
Reefer | Van (53ft Refrigerated) | temperature | TRUE | 44000
Dry Van | Van (53ft Dry) | dry | FALSE | 44000
Flatbed | Standard Flatbed | flatbed | FALSE | 48000
Step Deck | Step Deck Trailer | flatbed | FALSE | 46000
Hot Shot | Hotshot Gooseneck | specialized | FALSE | 16500
Power Only | Power Only (No Trailer) | specialized | FALSE | NULL
```

---

### trucks
```sql
CREATE TABLE trucks (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  equipment_type_id UUID        NOT NULL REFERENCES equipment_types(id),
  unit_number       TEXT,
  make              TEXT,
  model             TEXT,
  year              SMALLINT,
  color             TEXT,
  plate             TEXT,
  plate_state       CHAR(2),
  vin               TEXT,
  gross_weight_lbs  INT,
  status            TEXT        NOT NULL DEFAULT 'available'
                    CHECK (status IN ('available','dispatched','maintenance','inactive')),
  notes             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_trucks_company        ON trucks(company_id);
CREATE INDEX idx_trucks_status         ON trucks(company_id, status);
CREATE INDEX idx_trucks_equipment_type ON trucks(equipment_type_id);
```

---

### drivers
```sql
CREATE TABLE drivers (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id           UUID        REFERENCES users(id) ON DELETE SET NULL,
  truck_id          UUID        REFERENCES trucks(id) ON DELETE SET NULL,
  name              TEXT        NOT NULL,
  email             TEXT,
  phone             TEXT        NOT NULL,
  license_number    TEXT,
  license_state     CHAR(2),
  license_class     CHAR(1)     CHECK (license_class IN ('A','B','C')),
  license_expiry    DATE,
  endorsements      TEXT[],
  status            TEXT        NOT NULL DEFAULT 'available'
                    CHECK (status IN ('available','driving','off_duty','inactive')),
  home_city         TEXT,
  home_state        CHAR(2),
  notes             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_drivers_company   ON drivers(company_id);
CREATE INDEX idx_drivers_status    ON drivers(company_id, status);
CREATE INDEX idx_drivers_truck     ON drivers(truck_id);
CREATE INDEX idx_drivers_user      ON drivers(user_id);
```

---

## Domain 3 — Load Discovery

### loads
```sql
CREATE TABLE loads (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  source            TEXT        NOT NULL
                    CHECK (source IN ('dat','truckstop','broker_email','manual')),
  external_id       TEXT,
  broker_id         UUID        REFERENCES brokers(id) ON DELETE SET NULL,
  equipment_type_id UUID        REFERENCES equipment_types(id),

  -- Origin
  origin_city       TEXT        NOT NULL,
  origin_state      CHAR(2)     NOT NULL,
  origin_zip        TEXT,
  origin_lat        DECIMAL(9,6),
  origin_lng        DECIMAL(9,6),

  -- Destination
  dest_city         TEXT        NOT NULL,
  dest_state        CHAR(2)     NOT NULL,
  dest_zip          TEXT,
  dest_lat          DECIMAL(9,6),
  dest_lng          DECIMAL(9,6),

  -- Freight details
  commodity         TEXT,
  weight_lbs        INT,
  length_ft         INT,
  temp_min_f        SMALLINT,
  temp_max_f        SMALLINT,
  hazmat            BOOLEAN     NOT NULL DEFAULT FALSE,
  team_required     BOOLEAN     NOT NULL DEFAULT FALSE,

  -- Financials
  rate              DECIMAL(10,2),
  rate_type         TEXT        CHECK (rate_type IN ('flat','per_mile','negotiable')),
  miles             INT,
  rpm               DECIMAL(6,4),
  deadhead_miles    INT,

  -- Schedule
  pickup_date       DATE,
  pickup_earliest   TIME,
  pickup_latest     TIME,
  deliver_date      DATE,
  deliver_earliest  TIME,
  deliver_latest    TIME,

  -- AI scoring
  ai_score          SMALLINT    CHECK (ai_score BETWEEN 0 AND 100),
  ai_score_detail   JSONB,
  ai_scored_at      TIMESTAMPTZ,

  -- Status lifecycle
  status            TEXT        NOT NULL DEFAULT 'discovered'
                    CHECK (status IN (
                      'discovered','scored','outreach_sent','negotiating',
                      'pending_approval','approved','booked','passed','expired'
                    )),

  -- Metadata
  raw_data          JSONB,
  notes             TEXT,
  discovered_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at        TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
-- Core load board queries
CREATE INDEX idx_loads_company_status   ON loads(company_id, status);
CREATE INDEX idx_loads_score            ON loads(company_id, ai_score DESC NULLS LAST);
CREATE INDEX idx_loads_pickup_date      ON loads(company_id, pickup_date);
CREATE INDEX idx_loads_lane             ON loads(company_id, origin_state, dest_state);
CREATE INDEX idx_loads_broker           ON loads(broker_id);
CREATE INDEX idx_loads_source_ext       ON loads(source, external_id);
CREATE INDEX idx_loads_expires          ON loads(expires_at) WHERE status NOT IN ('booked','passed','expired');

-- Full-text search
CREATE INDEX idx_loads_fts ON loads
  USING GIN(to_tsvector('english',
    coalesce(origin_city,'') || ' ' ||
    coalesce(origin_state,'') || ' ' ||
    coalesce(dest_city,'') || ' ' ||
    coalesce(dest_state,'') || ' ' ||
    coalesce(commodity,'')
  ));

-- JSONB scoring detail
CREATE INDEX idx_loads_score_detail ON loads USING GIN(ai_score_detail);
```

---

### load_matches
```sql
CREATE TABLE load_matches (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  load_id           UUID        NOT NULL REFERENCES loads(id) ON DELETE CASCADE,
  truck_id          UUID        REFERENCES trucks(id) ON DELETE SET NULL,
  driver_id         UUID        REFERENCES drivers(id) ON DELETE SET NULL,
  match_score       SMALLINT    NOT NULL CHECK (match_score BETWEEN 0 AND 100),
  match_factors     JSONB,
  deadhead_miles    INT,
  status            TEXT        NOT NULL DEFAULT 'suggested'
                    CHECK (status IN ('suggested','reviewed','accepted','rejected')),
  reviewed_by       UUID        REFERENCES users(id),
  reviewed_at       TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (load_id, truck_id)
);
```
**Indexes:**
```sql
CREATE INDEX idx_load_matches_company ON load_matches(company_id, status);
CREATE INDEX idx_load_matches_load    ON load_matches(load_id);
CREATE INDEX idx_load_matches_truck   ON load_matches(truck_id);
```

---

### load_preferences
```sql
CREATE TABLE load_preferences (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE UNIQUE,
  equipment_types   TEXT[],
  min_rpm           DECIMAL(6,4) NOT NULL DEFAULT 2.00,
  min_pay           DECIMAL(10,2) NOT NULL DEFAULT 800.00,
  max_miles         INT         NOT NULL DEFAULT 1000,
  max_deadhead      INT         NOT NULL DEFAULT 100,
  max_weight_lbs    INT,
  commodities       TEXT[],
  exclude_hazmat    BOOLEAN     NOT NULL DEFAULT FALSE,
  avoid_weekends    BOOLEAN     NOT NULL DEFAULT FALSE,
  home_city         TEXT,
  home_state        CHAR(2),
  auto_outreach     BOOLEAN     NOT NULL DEFAULT FALSE,
  require_approval  BOOLEAN     NOT NULL DEFAULT TRUE,
  outreach_limit_daily INT      NOT NULL DEFAULT 50,
  min_score_outreach SMALLINT   NOT NULL DEFAULT 70,
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

### saved_lanes
```sql
CREATE TABLE saved_lanes (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name              TEXT,
  origin_city       TEXT,
  origin_state      CHAR(2),
  origin_radius_mi  INT         NOT NULL DEFAULT 50,
  dest_city         TEXT,
  dest_state        CHAR(2),
  dest_radius_mi    INT         NOT NULL DEFAULT 50,
  equipment_type_id UUID        REFERENCES equipment_types(id),
  polling_active    BOOLEAN     NOT NULL DEFAULT TRUE,
  last_polled_at    TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_saved_lanes_company  ON saved_lanes(company_id);
CREATE INDEX idx_saved_lanes_polling  ON saved_lanes(polling_active, last_polled_at)
  WHERE polling_active = TRUE;
```

---

## Domain 4 — Broker Management

### brokers
```sql
CREATE TABLE brokers (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        REFERENCES companies(id) ON DELETE CASCADE,
  name              TEXT        NOT NULL,
  legal_name        TEXT,
  mc_number         TEXT,
  dot_number        TEXT,
  address           TEXT,
  city              TEXT,
  state             CHAR(2),
  zip               TEXT,
  website           TEXT,
  primary_email     TEXT,
  primary_phone     TEXT,
  rating            DECIMAL(3,2) CHECK (rating BETWEEN 0 AND 5),
  total_loads       INT         NOT NULL DEFAULT 0,
  on_time_pct       DECIMAL(5,2),
  avg_rate          DECIMAL(10,2),
  avg_days_to_pay   INT,
  preferred         BOOLEAN     NOT NULL DEFAULT FALSE,
  blocked           BOOLEAN     NOT NULL DEFAULT FALSE,
  notes             TEXT,
  source            TEXT        CHECK (source IN ('manual','dat','truckstop','email')),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_brokers_company     ON brokers(company_id);
CREATE INDEX idx_brokers_mc          ON brokers(mc_number) WHERE mc_number IS NOT NULL;
CREATE INDEX idx_brokers_rating      ON brokers(company_id, rating DESC);
CREATE INDEX idx_brokers_preferred   ON brokers(company_id, preferred) WHERE preferred = TRUE;

CREATE INDEX idx_brokers_fts ON brokers
  USING GIN(to_tsvector('english',
    name || ' ' || coalesce(legal_name,'') || ' ' || coalesce(mc_number,'')
  ));

CREATE INDEX idx_brokers_name_trgm ON brokers
  USING GIN(name gin_trgm_ops);
```

---

### broker_contacts
```sql
CREATE TABLE broker_contacts (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  broker_id         UUID        NOT NULL REFERENCES brokers(id) ON DELETE CASCADE,
  name              TEXT        NOT NULL,
  title             TEXT,
  email             TEXT,
  phone             TEXT,
  phone_ext         TEXT,
  preferred_channel TEXT        CHECK (preferred_channel IN ('email','phone','both')),
  is_primary        BOOLEAN     NOT NULL DEFAULT FALSE,
  notes             TEXT,
  last_contacted_at TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_broker_contacts_broker  ON broker_contacts(broker_id);
CREATE INDEX idx_broker_contacts_primary ON broker_contacts(broker_id, is_primary)
  WHERE is_primary = TRUE;
CREATE INDEX idx_broker_contacts_email   ON broker_contacts(email) WHERE email IS NOT NULL;
```

---

## Domain 5 — Outreach

### email_conversations
```sql
CREATE TABLE email_conversations (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  load_id           UUID        REFERENCES loads(id) ON DELETE SET NULL,
  broker_id         UUID        REFERENCES brokers(id) ON DELETE SET NULL,
  broker_contact_id UUID        REFERENCES broker_contacts(id) ON DELETE SET NULL,
  subject           TEXT,
  external_thread_id TEXT,
  status            TEXT        NOT NULL DEFAULT 'draft'
                    CHECK (status IN (
                      'draft','sent','replied','negotiating',
                      'accepted','declined','expired','closed'
                    )),
  direction         TEXT        NOT NULL DEFAULT 'outbound'
                    CHECK (direction IN ('outbound','inbound')),
  message_count     INT         NOT NULL DEFAULT 0,
  last_message_at   TIMESTAMPTZ,
  rate_offered      DECIMAL(10,2),
  rate_received     DECIMAL(10,2),
  opened_at         TIMESTAMPTZ,
  replied_at        TIMESTAMPTZ,
  created_by        UUID        REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_convos_company        ON email_conversations(company_id, status);
CREATE INDEX idx_convos_load           ON email_conversations(load_id);
CREATE INDEX idx_convos_broker         ON email_conversations(broker_id);
CREATE INDEX idx_convos_external       ON email_conversations(external_thread_id)
  WHERE external_thread_id IS NOT NULL;
CREATE INDEX idx_convos_last_message   ON email_conversations(company_id, last_message_at DESC);
```

---

### email_messages
```sql
CREATE TABLE email_messages (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id   UUID        NOT NULL REFERENCES email_conversations(id) ON DELETE CASCADE,
  direction         TEXT        NOT NULL CHECK (direction IN ('outbound','inbound')),
  from_email        TEXT        NOT NULL,
  from_name         TEXT,
  to_email          TEXT        NOT NULL,
  cc_emails         TEXT[],
  subject           TEXT,
  body_text         TEXT,
  body_html         TEXT,
  external_message_id TEXT,
  ai_generated      BOOLEAN     NOT NULL DEFAULT FALSE,
  human_edited      BOOLEAN     NOT NULL DEFAULT FALSE,
  ai_model          TEXT,
  ai_prompt_tokens  INT,
  ai_completion_tokens INT,
  resend_id         TEXT,
  delivered_at      TIMESTAMPTZ,
  opened_at         TIMESTAMPTZ,
  clicked_at        TIMESTAMPTZ,
  bounced_at        TIMESTAMPTZ,
  bounce_reason     TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_messages_conversation ON email_messages(conversation_id, created_at);
CREATE INDEX idx_messages_external     ON email_messages(external_message_id)
  WHERE external_message_id IS NOT NULL;
CREATE INDEX idx_messages_direction    ON email_messages(conversation_id, direction);
```

---

## Domain 6 — Negotiation & Booking

### negotiations
```sql
CREATE TABLE negotiations (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  load_id           UUID        NOT NULL REFERENCES loads(id) ON DELETE CASCADE,
  conversation_id   UUID        REFERENCES email_conversations(id),
  broker_id         UUID        REFERENCES brokers(id),
  initial_ask_rate  DECIMAL(10,2),
  our_initial_offer DECIMAL(10,2),
  floor_rate        DECIMAL(10,2),
  current_broker_rate DECIMAL(10,2),
  current_our_rate  DECIMAL(10,2),
  final_rate        DECIMAL(10,2),
  market_rate       DECIMAL(10,2),
  turn_count        SMALLINT    NOT NULL DEFAULT 0,
  status            TEXT        NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','accepted','declined','stalled','cancelled')),
  ai_strategy       TEXT,
  outcome_notes     TEXT,
  started_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at       TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_negotiations_company  ON negotiations(company_id, status);
CREATE INDEX idx_negotiations_load     ON negotiations(load_id);
CREATE INDEX idx_negotiations_broker   ON negotiations(broker_id);
```

---

### bookings
```sql
CREATE TABLE bookings (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  load_id           UUID        NOT NULL REFERENCES loads(id),
  truck_id          UUID        REFERENCES trucks(id) ON DELETE SET NULL,
  driver_id         UUID        REFERENCES drivers(id) ON DELETE SET NULL,
  broker_id         UUID        REFERENCES brokers(id),
  negotiation_id    UUID        REFERENCES negotiations(id),
  rate_confirmed    DECIMAL(10,2) NOT NULL,
  miles             INT,
  rpm               DECIMAL(6,4),
  status            TEXT        NOT NULL DEFAULT 'pending_approval'
                    CHECK (status IN (
                      'pending_approval','approved','active',
                      'delivered','cancelled','tonu','disputed'
                    )),
  approved_by       UUID        REFERENCES users(id),
  approved_at       TIMESTAMPTZ,
  cancelled_by      UUID        REFERENCES users(id),
  cancelled_at      TIMESTAMPTZ,
  cancel_reason     TEXT,
  tonu_amount       DECIMAL(10,2),
  notes             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_bookings_company      ON bookings(company_id, status);
CREATE INDEX idx_bookings_load         ON bookings(load_id);
CREATE INDEX idx_bookings_truck        ON bookings(truck_id);
CREATE INDEX idx_bookings_driver       ON bookings(driver_id);
CREATE INDEX idx_bookings_pickup       ON bookings(company_id, created_at DESC);
```

---

### carrier_packets
```sql
CREATE TABLE carrier_packets (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  broker_id         UUID        NOT NULL REFERENCES brokers(id),
  status            TEXT        NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','submitted','approved','rejected','expired')),
  mc_certificate_url TEXT,
  insurance_url     TEXT,
  w9_url            TEXT,
  voided_check_url  TEXT,
  authority_url     TEXT,
  submitted_at      TIMESTAMPTZ,
  approved_at       TIMESTAMPTZ,
  expires_at        TIMESTAMPTZ,
  notes             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (company_id, broker_id)
);
```
**Indexes:**
```sql
CREATE INDEX idx_packets_company  ON carrier_packets(company_id);
CREATE INDEX idx_packets_broker   ON carrier_packets(broker_id);
CREATE INDEX idx_packets_status   ON carrier_packets(company_id, status);
```

---

### rate_confirmations
```sql
CREATE TABLE rate_confirmations (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id        UUID        NOT NULL REFERENCES bookings(id) ON DELETE CASCADE UNIQUE,
  broker_id         UUID        REFERENCES brokers(id),
  rate_amount       DECIMAL(10,2) NOT NULL,
  origin_city       TEXT,
  origin_state      CHAR(2),
  dest_city         TEXT,
  dest_state        CHAR(2),
  pickup_date       DATE,
  deliver_date      DATE,
  commodity         TEXT,
  weight_lbs        INT,
  document_url      TEXT,
  external_ref      TEXT,
  signed_by         UUID        REFERENCES users(id),
  signed_at         TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_rate_cons_booking ON rate_confirmations(booking_id);
CREATE INDEX idx_rate_cons_broker  ON rate_confirmations(broker_id);
```

---

## Domain 7 — Operations

### dispatches
```sql
CREATE TABLE dispatches (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  booking_id        UUID        NOT NULL REFERENCES bookings(id) ON DELETE CASCADE UNIQUE,
  truck_id          UUID        REFERENCES trucks(id),
  driver_id         UUID        REFERENCES drivers(id),
  status            TEXT        NOT NULL DEFAULT 'assigned'
                    CHECK (status IN (
                      'assigned','en_route_pickup','at_pickup',
                      'loaded','en_route_delivery','at_delivery','delivered'
                    )),
  pickup_appt       TIMESTAMPTZ,
  pickup_actual     TIMESTAMPTZ,
  deliver_appt      TIMESTAMPTZ,
  deliver_actual    TIMESTAMPTZ,
  last_location     TEXT,
  last_location_at  TIMESTAMPTZ,
  driver_notes      TEXT,
  dispatcher_notes  TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_dispatches_company    ON dispatches(company_id, status);
CREATE INDEX idx_dispatches_driver     ON dispatches(driver_id);
CREATE INDEX idx_dispatches_truck      ON dispatches(truck_id);
```

---

### dispatch_events
```sql
CREATE TABLE dispatch_events (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  dispatch_id       UUID        NOT NULL REFERENCES dispatches(id) ON DELETE CASCADE,
  event_type        TEXT        NOT NULL,
  status_before     TEXT,
  status_after      TEXT,
  location          TEXT,
  notes             TEXT,
  recorded_by       UUID        REFERENCES users(id),
  recorded_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_dispatch_events_dispatch ON dispatch_events(dispatch_id, recorded_at DESC);
```

---

## Domain 8 — Finance

### settlements
```sql
CREATE TABLE settlements (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  booking_id        UUID        NOT NULL REFERENCES bookings(id) UNIQUE,
  gross             DECIMAL(10,2) NOT NULL,
  fuel_cost         DECIMAL(10,2) NOT NULL DEFAULT 0,
  broker_fee        DECIMAL(10,2) NOT NULL DEFAULT 0,
  factoring_fee     DECIMAL(10,2) NOT NULL DEFAULT 0,
  tolls             DECIMAL(10,2) NOT NULL DEFAULT 0,
  driver_pay        DECIMAL(10,2) NOT NULL DEFAULT 0,
  other_deductions  DECIMAL(10,2) NOT NULL DEFAULT 0,
  net               DECIMAL(10,2) GENERATED ALWAYS AS (
                      gross - fuel_cost - broker_fee - factoring_fee
                      - tolls - driver_pay - other_deductions
                    ) STORED,
  status            TEXT        NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','invoiced','paid','disputed','written_off')),
  invoice_number    TEXT,
  invoice_date      DATE,
  due_date          DATE,
  paid_date         DATE,
  payment_method    TEXT,
  factored          BOOLEAN     NOT NULL DEFAULT FALSE,
  factor_company    TEXT,
  notes             TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_settlements_company   ON settlements(company_id, status);
CREATE INDEX idx_settlements_booking   ON settlements(booking_id);
CREATE INDEX idx_settlements_paid_date ON settlements(company_id, paid_date);
CREATE INDEX idx_settlements_invoice   ON settlements(invoice_number) WHERE invoice_number IS NOT NULL;
```

---

### transactions
```sql
CREATE TABLE transactions (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  settlement_id     UUID        REFERENCES settlements(id) ON DELETE SET NULL,
  receipt_id        UUID        REFERENCES receipts(id) ON DELETE SET NULL,
  type              TEXT        NOT NULL CHECK (type IN ('income','expense')),
  category          TEXT        NOT NULL,
  subcategory       TEXT,
  amount            DECIMAL(10,2) NOT NULL,
  description       TEXT,
  merchant          TEXT,
  transaction_date  DATE        NOT NULL,
  payment_method    TEXT,
  reference_number  TEXT,
  notes             TEXT,
  created_by        UUID        REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_transactions_company  ON transactions(company_id, transaction_date DESC);
CREATE INDEX idx_transactions_category ON transactions(company_id, category, transaction_date);
CREATE INDEX idx_transactions_type     ON transactions(company_id, type);
CREATE INDEX idx_transactions_settlement ON transactions(settlement_id);

CREATE INDEX idx_transactions_fts ON transactions
  USING GIN(to_tsvector('english',
    coalesce(description,'') || ' ' || coalesce(merchant,'')
  ));
```

---

### receipts
```sql
CREATE TABLE receipts (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  transaction_id    UUID        REFERENCES transactions(id) ON DELETE SET NULL,
  merchant          TEXT,
  receipt_date      DATE,
  receipt_number    TEXT,
  invoice_number    TEXT,
  subtotal          DECIMAL(10,2),
  tax               DECIMAL(10,2),
  tip               DECIMAL(10,2),
  total             DECIMAL(10,2),
  payment_method    TEXT,
  category          TEXT,
  original_url      TEXT,
  processed_url     TEXT,
  thumbnail_url     TEXT,
  file_type         TEXT,
  file_size_bytes   INT,
  ocr_status        TEXT        NOT NULL DEFAULT 'pending'
                    CHECK (ocr_status IN ('pending','processing','complete','failed','skipped')),
  review_status     TEXT        NOT NULL DEFAULT 'pending'
                    CHECK (review_status IN ('pending','approved','rejected')),
  reviewed_by       UUID        REFERENCES users(id),
  reviewed_at       TIMESTAMPTZ,
  duplicate_of      UUID        REFERENCES receipts(id),
  created_by        UUID        REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_receipts_company      ON receipts(company_id, receipt_date DESC);
CREATE INDEX idx_receipts_ocr_status   ON receipts(company_id, ocr_status);
CREATE INDEX idx_receipts_review       ON receipts(company_id, review_status);
CREATE INDEX idx_receipts_merchant_trgm ON receipts USING GIN(merchant gin_trgm_ops)
  WHERE merchant IS NOT NULL;

-- Duplicate detection
CREATE INDEX idx_receipts_dedup ON receipts(company_id, merchant, receipt_date, total)
  WHERE duplicate_of IS NULL;
```

---

### receipt_line_items
```sql
CREATE TABLE receipt_line_items (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_id        UUID        NOT NULL REFERENCES receipts(id) ON DELETE CASCADE,
  description       TEXT,
  quantity          DECIMAL(10,3),
  unit_price        DECIMAL(10,2),
  amount            DECIMAL(10,2),
  category          TEXT,
  sort_order        SMALLINT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_line_items_receipt ON receipt_line_items(receipt_id);
```

---

## Domain 9 — Intelligence

### ai_insights
```sql
CREATE TABLE ai_insights (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  type              TEXT        NOT NULL
                    CHECK (type IN (
                      'savings_opportunity','duplicate_detected','rate_alert',
                      'lane_performance','broker_trend','budget_warning',
                      'fuel_optimization','load_recommendation','general'
                    )),
  priority          TEXT        NOT NULL DEFAULT 'medium'
                    CHECK (priority IN ('critical','high','medium','low')),
  title             TEXT        NOT NULL,
  body              TEXT        NOT NULL,
  data              JSONB,
  entity_type       TEXT,
  entity_id         UUID,
  action_url        TEXT,
  dismissed         BOOLEAN     NOT NULL DEFAULT FALSE,
  dismissed_by      UUID        REFERENCES users(id),
  dismissed_at      TIMESTAMPTZ,
  ai_model          TEXT,
  generated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at        TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_insights_company      ON ai_insights(company_id, dismissed, priority);
CREATE INDEX idx_insights_type         ON ai_insights(company_id, type);
CREATE INDEX idx_insights_entity       ON ai_insights(entity_type, entity_id);
CREATE INDEX idx_insights_generated    ON ai_insights(company_id, generated_at DESC);
```

---

### ocr_results
```sql
CREATE TABLE ocr_results (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  receipt_id        UUID        NOT NULL REFERENCES receipts(id) ON DELETE CASCADE UNIQUE,
  engine            TEXT        NOT NULL DEFAULT 'aws_textract',
  raw_text          TEXT,
  raw_response      JSONB,
  structured_data   JSONB,
  confidence_overall DECIMAL(5,4),
  confidence_fields  JSONB,
  low_confidence_fields TEXT[],
  page_count        SMALLINT    NOT NULL DEFAULT 1,
  processing_ms     INT,
  tokens_used       INT,
  status            TEXT        NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','processing','complete','failed')),
  error_message     TEXT,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_ocr_receipt           ON ocr_results(receipt_id);
CREATE INDEX idx_ocr_status            ON ocr_results(status);
CREATE INDEX idx_ocr_structured        ON ocr_results USING GIN(structured_data);
```

---

## Domain 10 — System

### documents
```sql
CREATE TABLE documents (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  entity_type       TEXT        NOT NULL
                    CHECK (entity_type IN (
                      'booking','dispatch','carrier_packet','settlement',
                      'truck','driver','company','receipt'
                    )),
  entity_id         UUID        NOT NULL,
  type              TEXT        NOT NULL
                    CHECK (type IN (
                      'rate_con','bol','pod','invoice','insurance',
                      'mc_certificate','w9','voided_check','other'
                    )),
  name              TEXT        NOT NULL,
  file_url          TEXT        NOT NULL,
  file_type         TEXT,
  file_size_bytes   INT,
  uploaded_by       UUID        REFERENCES users(id),
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_documents_company     ON documents(company_id);
CREATE INDEX idx_documents_entity      ON documents(entity_type, entity_id);
CREATE INDEX idx_documents_type        ON documents(company_id, type);
```

---

### notifications
```sql
CREATE TABLE notifications (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id           UUID        REFERENCES users(id) ON DELETE CASCADE,
  type              TEXT        NOT NULL
                    CHECK (type IN (
                      'load_match','booking_approval','broker_reply',
                      'negotiation_update','dispatch_status','ocr_complete',
                      'budget_warning','payment_received','ai_insight',
                      'system','team_invite'
                    )),
  priority          TEXT        NOT NULL DEFAULT 'normal'
                    CHECK (priority IN ('urgent','high','normal','low')),
  title             TEXT        NOT NULL,
  body              TEXT,
  action_url        TEXT,
  entity_type       TEXT,
  entity_id         UUID,
  read              BOOLEAN     NOT NULL DEFAULT FALSE,
  read_at           TIMESTAMPTZ,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```
**Indexes:**
```sql
CREATE INDEX idx_notifs_user           ON notifications(user_id, read, created_at DESC);
CREATE INDEX idx_notifs_company        ON notifications(company_id, created_at DESC);
CREATE INDEX idx_notifs_unread         ON notifications(user_id, created_at DESC)
  WHERE read = FALSE;
```

---

### audit_logs
```sql
CREATE TABLE audit_logs (
  id                UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id        UUID        REFERENCES companies(id) ON DELETE SET NULL,
  user_id           UUID        REFERENCES users(id) ON DELETE SET NULL,
  action            TEXT        NOT NULL,
  entity_type       TEXT        NOT NULL,
  entity_id         UUID,
  before_data       JSONB,
  after_data        JSONB,
  ip_address        INET,
  user_agent        TEXT,
  metadata          JSONB,
  created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Immutability enforcement
CREATE RULE no_update_audit AS ON UPDATE TO audit_logs DO INSTEAD NOTHING;
CREATE RULE no_delete_audit AS ON DELETE TO audit_logs DO INSTEAD NOTHING;
```
**Indexes:**
```sql
CREATE INDEX idx_audit_company         ON audit_logs(company_id, created_at DESC);
CREATE INDEX idx_audit_user            ON audit_logs(user_id, created_at DESC);
CREATE INDEX idx_audit_entity          ON audit_logs(entity_type, entity_id);
CREATE INDEX idx_audit_action          ON audit_logs(action, created_at DESC);

-- Partitioning by month at scale (>10M rows)
-- CREATE TABLE audit_logs_2025_01 PARTITION OF audit_logs
--   FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
```

---

## Relationship Map

```
companies ─┬─ users ────────────── role ─── roles ─── role_permissions ─── permissions
           ├─ trucks ──────────── equipment_types
           ├─ drivers ─────────── trucks
           ├─ loads ────────────── brokers ─── broker_contacts
           │   └─ load_matches
           ├─ saved_lanes
           ├─ load_preferences
           ├─ email_conversations ─── email_messages
           │   └─ negotiations
           ├─ bookings ─┬──────── rate_confirmations
           │             ├──────── carrier_packets
           │             └──────── dispatches ─── dispatch_events
           ├─ settlements ──────── transactions ─── receipts ─── receipt_line_items
           │                                                        └─── ocr_results
           ├─ documents
           ├─ ai_insights
           ├─ notifications
           └─ audit_logs
```

---

## Row Level Security (RLS) Policies

```sql
-- Enable RLS on all company-scoped tables
ALTER TABLE loads ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
-- (repeat for all tables with company_id)

-- Standard policy pattern
CREATE POLICY company_isolation ON loads
  USING (company_id = current_setting('app.company_id')::UUID);

-- Audit logs: read-only for company, no delete
CREATE POLICY audit_read ON audit_logs FOR SELECT
  USING (company_id = current_setting('app.company_id')::UUID);
```

---

## Indexing Strategy Summary

| Strategy | Applied To | Purpose |
|---|---|---|
| **Composite (company_id, status)** | loads, bookings, settlements, dispatches | Core list queries — company-scoped, filtered by status |
| **Composite (company_id, date DESC)** | transactions, settlements, notifications | Chronological feeds, recent-first |
| **Partial index (WHERE active)** | saved_lanes, notifications, loads | Avoid indexing irrelevant rows, smaller index |
| **GIN full-text search** | loads, brokers, transactions | Fast free-text search across fields |
| **GIN trigram (gin_trgm_ops)** | brokers.name, receipts.merchant | Typo-tolerant autocomplete |
| **GIN JSONB** | ai_score_detail, structured_data, ocr_results | Query inside JSON columns |
| **Unique partial** | email_conversations(external_thread_id) | Nullable unique, inbound thread matching |
| **Foreign key indexes** | All FK columns | Prevent sequential scans on joins |
| **Immutable rule** | audit_logs | Prevent UPDATE/DELETE at database layer |

---

## Migration Order (dependency-safe)

```
1.  extensions
2.  companies
3.  equipment_types
4.  roles
5.  permissions
6.  role_permissions
7.  users
8.  trucks
9.  drivers
10. brokers
11. broker_contacts
12. load_preferences
13. saved_lanes
14. loads
15. load_matches
16. email_conversations
17. email_messages
18. negotiations
19. bookings
20. carrier_packets
21. rate_confirmations
22. dispatches
23. dispatch_events
24. settlements
25. transactions
26. receipts
27. receipt_line_items
28. ocr_results
29. ai_insights
30. documents
31. notifications
32. audit_logs
33. RLS policies
34. Seed data (equipment_types, system roles, permissions)
```

---

*Phase 2 Complete — 32 tables, 25 domains, production-ready.*
*Ready for Phase 3 when architecture arrives.*
