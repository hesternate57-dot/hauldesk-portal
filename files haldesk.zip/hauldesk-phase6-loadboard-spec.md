# HaulDesk — Phase 6: Load Search Board
**Version:** 1.0 | **Phase:** 6 of 21

---

## 1. Layout Architecture

```
┌──────────────────┬──────────────────────────────────────────┐
│  FILTER PANEL    │  RESULTS AREA                            │
│  (280px fixed)   │                                          │
│                  │  [Stats: 28 found · avg $2.94/mi]       │
│  🔍 Origin       │  [Sort ▾] [Cards|List toggle]           │
│  🎯 Destination  │                                          │
│  📏 Deadhead     │  ┌──────┐ ┌──────┐ ┌──────┐            │
│  📅 Pickup Date  │  │ #1   │ │ #2   │ │ #3   │            │
│  🚛 Equipment    │  │BEST  │ │      │ │      │            │
│  ❄️ Temp Range   │  │      │ │      │ │      │            │
│     (reefer only)│  └──────┘ └──────┘ └──────┘            │
│  ⚖️ Weight       │                                          │
│  💰 Rate Filters │  [more loads...]                        │
│                  │                                          │
│  [Search]        │                                          │
│  [Reset Filters] │                                          │
└──────────────────┴──────────────────────────────────────────┘

Load Detail Drawer (right slide-in on card click):
├── Full route + broker profile
├── Equipment + temperature (HUGE for reefer)
├── Weight gauge (visual)
├── Rate breakdown
├── Pickup/delivery details
├── AI score breakdown
└── Book / Contact / Pass actions
```

---

## 2. Filter Panel Specification

### Origin/Destination Search
- City + State autocomplete (type-ahead, populated from common freight cities)
- "Use my current location" (GPS, pre-fills from `load_preferences.home_city`)
- ⇄ Swap button between origin and destination
- Destination can be set to "Anywhere"

### Deadhead Radius
- Slider: 0–200 miles, step 5
- Default: from `load_preferences.max_deadhead`
- Shown as "within X mi of origin"

### Pickup Date
- Single date or date range
- Quick selects: Today, Tomorrow, This Week, Next Week
- Defaults to today

### Equipment Type (multi-select chips)
```
[ ] Dry Van     [ ] Reefer       [ ] Flatbed
[ ] Step Deck   [ ] Hot Shot     [ ] Power Only
```
When Reefer selected → show Temperature Range section

### Temperature Range (Reefer only)
```
Temp classification:
  ○ Any temp
  ○ Frozen       (≤ 32°F) — blue
  ○ Fresh/Produce (34–50°F) — green
  ○ Chilled      (50–65°F) — amber
  ○ Custom range: [___°F] to [___°F]
```

### Weight Filter
- Min / Max weight in lbs
- Slider: 0 – 44,000 lbs
- Quick selects: Light (<20k), Standard (<40k), Heavy (any)
- Defaults from `load_preferences.max_weight_lbs`

### Rate Filters
- Minimum $/mile (slider, $1.00 – $5.00)
- Minimum total pay (slider, $300 – $5,000)
- Both default from `load_preferences`

---

## 3. Load Card Specification

### Card Information Hierarchy
```
[★ BEST MATCH]           [AI Score: 94]

Houston, TX ──────────→  Van Buren, AR
445 miles

TFSL Logistics · Thomas Evans

┌─── RATE ────┐  ┌─── PER MILE ───┐
│  $1,600     │  │   $3.60 / mi   │
└─────────────┘  └────────────────┘

❄️ REEFER  [−10°F FROZEN]  ← prominent, color-coded badge
⚖️ 9,000 lbs  ████░░░░░░░░  20.5% capacity  ← weight bar

Pickup:   May 4 · 0900–1500
Deliver:  May 5 · 0830
Deadhead: 12 mi

[────────────────────░░░░░] 94 / 100

[Book It]  [📧 Contact]  [Pass]
```

### Temperature Display Rules
| Range | Label | Color | Icon |
|---|---|---|---|
| ≤ 0°F | DEEP FROZEN | Deep blue | 🧊 |
| 1–32°F | FROZEN | Blue | ❄️ |
| 33–40°F | FRESH PRODUCE | Teal | 🥬 |
| 41–55°F | CHILLED | Green | 🌡️ |
| 56–65°F | CONTROLLED TEMP | Amber | 🌡️ |

Temperature badge is always:
- Full-width on the card (not an afterthought)
- High contrast, easy to read at a glance
- Shows exact temp + classification

### Weight Display Rules
| Utilization | Color | Label |
|---|---|---|
| < 50% | Teal | Light |
| 50–75% | Blue | Standard |
| 75–90% | Amber | Heavy |
| > 90% | Red | Near Limit |

Weight shown as:
- Raw number: **9,000 lbs**
- Progress bar: fills to % of 44,000 lb legal max
- Classification label

---

## 4. List View Specification

Table columns:
```
Rank | Route | Miles | Equipment | Temp | Weight | $/mi | Total | Pickup | Deadhead | Score | Actions
```

Temperature displayed as colored badge inline in the Equipment column.
Weight displayed as number + mini bar in its own column.

---

## 5. Load Detail Drawer

Slide-in from right (same pattern as preferences drawer), 520px wide:
- Broker card: name, company, MC#, rating stars, past load history
- Route map placeholder (Phase 8+)
- Equipment block: HUGE temp display for reefer
- Weight gauge: full circular/bar gauge
- Rate breakdown: gross, estimated fuel, est. broker fee, projected net
- Schedule: pickup window, delivery window, total transit time
- AI score breakdown: rpm score, deadhead score, preference match, broker score
- Action row: Book It (primary) | Email Broker | Pass

---

## 6. Sorting Options
- Best Match (AI score — default)
- Highest $/Mile
- Highest Total Rate
- Lowest Deadhead
- Earliest Pickup
- Lightest Load (weight asc)

---

## 7. State Management
- All filter state in URL params (shareable/bookmarkable)
- Filter changes trigger debounced search (300ms)
- Results animate in on change
- Empty state: "No loads match your filters — try widening your search"
- Loading state: skeleton cards

