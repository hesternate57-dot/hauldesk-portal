# HaulDesk — Phase 13: Active Dispatch Management
**Version:** 1.0 | **Phase:** 13 of 21

---

## 1. Purpose

Active Dispatch Management is the real-time operational layer — the screen a dispatcher watches all day to know where every truck is, what's running late, and what needs intervention. Every load that gets booked flows through this board until it's delivered.

---

## 2. Status Pipeline

```
BOOKED → ASSIGNED → AT PICKUP → IN TRANSIT → DELIVERED
  (confirmed  (driver +    (truck at     (wheels       (POD
   not yet    truck set)    shipper,     rolling)      received)
   assigned)               loading)
```

Each status transition is triggered by:
- **BOOKED → ASSIGNED:** Dispatcher assigns driver + truck in portal
- **ASSIGNED → AT PICKUP:** Driver taps "Arrived at pickup" (future: auto-geofence)
- **AT PICKUP → IN TRANSIT:** Driver taps "Loaded and departed"
- **IN TRANSIT → DELIVERED:** Driver taps "Delivered" or dispatcher confirms

---

## 3. Screen Layout

### Primary: Kanban Board
```
┌─────────────────────────────────────────────────────────────┐
│ Active Dispatch    [Today: 14 runs · 2 issues · 91% on-time]│
├─────────────────────────────────────────────────────────────┤
│  [Kanban | Table]   [Filter: All Drivers ▾]   [+ New Disp.] │
├──────────┬──────────┬──────────┬──────────┬─────────────────┤
│ BOOKED   │ ASSIGNED │ AT PICKUP│ IN TRANSIT│ DELIVERED TODAY │
│ 2 loads  │ 1 load   │ 1 load   │ 2 loads  │ 8 loads         │
│──────────│──────────│──────────│──────────│─────────────────│
│ [card]   │ [card]   │ [card]   │ [card]   │ [card]          │
│ [card]   │          │          │ [card] ⚠ │ [card]          │
└──────────┴──────────┴──────────┴──────────┴─────────────────┘
```

### Secondary: Table View
Full sortable table with all active dispatches.

---

## 4. Dispatch Card Specification

```
┌─────────────────────────────────────┐
│ ● ON TIME           [⚠ ISSUE FLAG]  │
│                                     │
│ Houston, TX → Van Buren, AR         │
│ 445 mi · TFSL Logistics             │
│                                     │
│ 🧑 Sandra Torres · Unit 002 Kenworth│
│                                     │
│ ❄️  −10°F FROZEN  ⚖️  9,000 lbs     │
│                                     │
│ Pickup:  May 4 · 0900–1500          │
│ Deliver: May 5 · 0830 ETA           │
│                                     │
│ ⏱ Last update: 22 min ago           │
│                                     │
│ [Update Status ▾]  [Contact]         │
└─────────────────────────────────────┘
```

### Issue States
| State | Dot Color | Label | Trigger |
|---|---|---|---|
| On Time | Teal | ON TIME | ETA within window |
| At Risk | Amber | AT RISK | ETA within 30min of window |
| Delayed | Red | DELAYED | Missed pickup or delivery window |
| Issue | Red + pulse | ISSUE | Dispatcher flagged manually |
| Breakdown | Red + pulse | BREAKDOWN | Driver reported breakdown |

---

## 5. Dispatch Detail Drawer

Slide-in panel (560px) with:

**Header:** Route, broker, driver, truck  
**Status controls:** One-click status update buttons  
**Timeline:** Full event history with timestamps  
**Cargo block:** Equipment type, temp (reefer), weight  
**Schedule:** Pickup window, delivery window, current ETA  
**Contact bar:** Call Driver, Email Broker, Flag Issue  
**Issue log:** If any issues exist, shown with timestamps  

---

## 6. Issue & Delay Tracking

Issues are flagged via:
1. Dispatcher manually flags in portal
2. Driver reports in mobile app (Phase 16+)
3. Automated: load not picked up 30min after window close

Issue types:
```
DELAY          Late to pickup or delivery
BREAKDOWN      Vehicle mechanical issue
WEATHER        Weather-related delay
SHIPPER_DELAY  Shipper not ready
RECEIVER_DELAY Receiver not ready
REFUSED        Load refused at delivery
ACCIDENT       Vehicle incident
OTHER          Free text
```

Each issue creates:
- `dispatch_events` record
- Notification to dispatcher
- Notification to broker (if applicable)
- Audit log entry

---

## 7. Operational Dashboard Widgets

Three summary widgets above the kanban:
1. **Pipeline Status** — count per status column
2. **Today's P&L Preview** — gross vs estimated net for today's delivers
3. **Driver Status** — which drivers are where (driving/available/off-duty)

---

## 8. API Endpoints

```
dispatches.list(filters)          → All active dispatches
dispatches.get(id)                → Full dispatch + events
dispatches.updateStatus(id, status) → Advance status
dispatches.assignDriver(id, driverId, truckId) → Assignment
dispatches.flagIssue(id, type, note) → Create issue record
dispatches.getTimeline(id)        → All dispatch_events
dispatches.contactDriver(id)      → Get driver contact info
```

---

*Phase 13 complete — spec delivered. All screens integrated in portal.*
