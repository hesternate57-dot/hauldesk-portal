# HaulDesk — Phase 3: Authentication & User Management
**Version:** 1.0 | **Phase:** 3 of 21

---

## 1. Authentication Flows

### 1.1 Login Flow
```
User enters email + password
  ↓
Clerk validates credentials
  ↓ success              ↓ fail
MFA required?         Show error
  ↓ yes    ↓ no         (rate limit after 5 attempts)
Enter TOTP  Load app
  ↓
Validate TOTP (Clerk)
  ↓ valid   ↓ invalid
Load app   Show error (3 attempts before lockout)
```

### 1.2 Registration Flow
```
Step 1: Company Info
  → Company name, MC number, DOT number, phone
Step 2: Personal Info
  → Name, email, password (min 12 chars)
Step 3: Email Verification
  → 6-digit code sent to email
Step 4: Plan Selection
  → Starter / Growth / Pro / Enterprise
Step 5: Setup Complete
  → Redirect to onboarding → dashboard
```

### 1.3 Forgot Password Flow
```
Enter email address
  ↓
Clerk sends reset link (15-min expiry)
  ↓
User clicks link → Reset Password form
  ↓
New password + confirm (min 12 chars, complexity enforced)
  ↓
Redirect to login with success message
```

### 1.4 MFA Flow
```
Owner enables MFA enforcement for company
  ↓
Users prompted to setup MFA on next login
  ↓
Scan QR code (TOTP — Google Auth / Authy)
  ↓
Enter 6-digit code to verify
  ↓
Show 8 backup codes (one-time use, store securely)
  ↓
MFA active on account
```

### 1.5 Email Verification Flow
```
Registration complete
  ↓
6-digit OTP sent to email (10-min expiry)
  ↓
User enters code in-app
  ↓ match          ↓ expired
Account active    Resend code option (max 3 resends)
```

---

## 2. Roles & RBAC

### Role Definitions

| Role | Description | Typical User |
|---|---|---|
| **Owner** | Full platform access. Billing, team management, all data. | Company owner |
| **Admin** | All ops access. Cannot manage billing or delete company. | Office manager |
| **Dispatcher** | Load discovery, outreach, booking workflow. No financial. | Freight dispatcher |
| **Driver** | View assigned loads, update dispatch status, upload receipts. | Truck driver |
| **Accountant** | Settlement, transactions, receipts, reports. No load ops. | Bookkeeper / accountant |
| **Viewer** | Read-only across all modules. No writes, no exports. | Partner / investor |

### RBAC Permission Matrix

| Permission | Owner | Admin | Dispatcher | Driver | Accountant | Viewer |
|---|:---:|:---:|:---:|:---:|:---:|:---:|
| **Loads** |
| loads.view | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| loads.search | ✓ | ✓ | ✓ | | | |
| loads.pass | ✓ | ✓ | ✓ | | | |
| loads.export | ✓ | ✓ | | | ✓ | |
| **Outreach** |
| outreach.view | ✓ | ✓ | ✓ | | | ✓ |
| outreach.send | ✓ | ✓ | ✓ | | | |
| outreach.draft | ✓ | ✓ | ✓ | | | |
| **Bookings** |
| bookings.view | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| bookings.create | ✓ | ✓ | ✓ | | | |
| bookings.approve | ✓ | ✓ | | | | |
| bookings.cancel | ✓ | ✓ | | | | |
| **Negotiations** |
| negotiations.view | ✓ | ✓ | ✓ | | | ✓ |
| negotiations.manage | ✓ | ✓ | ✓ | | | |
| **Dispatch** |
| dispatch.view | ✓ | ✓ | ✓ | ✓ | | ✓ |
| dispatch.update | ✓ | ✓ | ✓ | ✓ | | |
| dispatch.assign | ✓ | ✓ | ✓ | | | |
| **Settlement / Finance** |
| settlements.view | ✓ | ✓ | | | ✓ | ✓ |
| settlements.update | ✓ | ✓ | | | ✓ | |
| settlements.export | ✓ | ✓ | | | ✓ | |
| transactions.view | ✓ | ✓ | | | ✓ | ✓ |
| transactions.create | ✓ | ✓ | | | ✓ | |
| receipts.upload | ✓ | ✓ | ✓ | ✓ | ✓ | |
| receipts.approve | ✓ | ✓ | | | ✓ | |
| budgets.view | ✓ | ✓ | | | ✓ | ✓ |
| budgets.manage | ✓ | ✓ | | | ✓ | |
| **Reports** |
| reports.view | ✓ | ✓ | ✓ | | ✓ | ✓ |
| reports.generate | ✓ | ✓ | | | ✓ | |
| reports.export | ✓ | ✓ | | | ✓ | |
| **Fleet** |
| fleet.view | ✓ | ✓ | ✓ | ✓ | | ✓ |
| fleet.manage | ✓ | ✓ | | | | |
| drivers.view | ✓ | ✓ | ✓ | | | ✓ |
| drivers.manage | ✓ | ✓ | | | | |
| **Team & Admin** |
| team.view | ✓ | ✓ | | | | |
| team.invite | ✓ | ✓ | | | | |
| team.manage_roles | ✓ | | | | | |
| team.deactivate | ✓ | | | | | |
| billing.view | ✓ | | | | | |
| billing.manage | ✓ | | | | | |
| **System** |
| audit.view | ✓ | ✓ | | | | |
| settings.view | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| settings.manage | ✓ | ✓ | | | | |
| mfa.enforce | ✓ | | | | | |

---

## 3. API Endpoints

### Auth (Clerk-managed, webhook-driven)
```
POST /api/webhooks/clerk          → User events (created, updated, deleted)
GET  /api/auth/session            → Current session + company context
POST /api/auth/verify-company     → Validate company_id from JWT claims
```

### Users (tRPC)
```
users.me                          → Current user profile
users.update                      → Update name, phone, avatar
users.list                        → Company users (admin+)
users.invite                      → Send invite email (admin+)
users.updateRole                  → Change user role (owner only)
users.deactivate                  → Soft-deactivate user (owner only)
users.reactivate                  → Restore deactivated user (owner only)
```

### Roles & Permissions (tRPC)
```
roles.list                        → All roles for company
roles.getPermissions              → Permissions for a role
permissions.list                  → All available permissions
permissions.check(resource,action)→ Can current user do this?
```

### MFA (tRPC)
```
mfa.getStatus                     → Is MFA enabled / enforced?
mfa.setup                         → Begin TOTP setup (returns QR URI)
mfa.verify                        → Confirm TOTP code after setup
mfa.disable                       → Remove MFA (requires password confirm)
mfa.enforceForCompany             → Owner forces MFA for all users
mfa.getBackupCodes                → One-time download of backup codes
```

---

## 4. Component Specifications

### Auth Components
```
<AuthLayout>          → Split-panel layout (form left, feature right)
<LoginForm>           → Email, password, submit, forgot link
<MFAStep>             → 6-digit TOTP input (auto-advance), backup code link
<RegisterFlow>        → Multi-step wizard (4 steps)
<ForgotPassword>      → Email input, submit, success state
<PasswordReset>       → New password + confirm, strength meter
<EmailVerify>         → 6-digit OTP input, resend button, countdown
```

### User Management Components
```
<TeamTable>           → User list, role badge, status, actions menu
<InviteModal>         → Email + role select + custom message
<RoleSelect>          → Dropdown with role descriptions
<PermissionMatrix>    → 6-col table of all permissions, color-coded
<UserCard>            → Avatar, name, role, last active, actions
<ProfileForm>         → Edit name, phone, avatar upload
<PasswordChange>      → Current + new + confirm, strength indicator
<MFASetupCard>        → QR code, TOTP input, backup codes display
```

---

## 5. Security Notes

- **Password policy:** min 12 chars, uppercase + number + symbol required. Clerk built-in breach detection (HaveIBeenPwned check).
- **Session:** JWT 15-min expiry, refresh token 30 days. Revocable via Clerk dashboard instantly.
- **Rate limiting:** 5 failed login attempts → 15-min lockout. Reset link rate: 3/hour per email.
- **MFA backup codes:** 8 codes, one-time use, SHA-256 hashed in Clerk. Shown only once — user must download.
- **Invite expiry:** Invite tokens expire 72 hours after issue.
- **Role changes:** Write to audit_log immediately. Cannot demote the last Owner.
- **Deactivation:** Soft-delete only. Clerk session revoked immediately. Data retained.

---

*Phase 3 Complete — auth system specified. All screens integrated in portal.*
