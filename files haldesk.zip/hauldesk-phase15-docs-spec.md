# HaulDesk — Phase 15: Receipt & Document Center
**Version:** 1.0 | **Phase:** 15 of 21

---

## 1. Document Types

| Type | Description | Auto-OCR | Linked To |
|---|---|---|---|
| **Receipt** | Fuel, maintenance, meals, supplies | ✓ | Transaction |
| **Rate Confirmation** | Broker rate con PDF | ✓ (structured) | Booking |
| **Bill of Lading** | Pickup document | ✗ | Dispatch |
| **Proof of Delivery** | Delivery confirmation | ✗ | Dispatch |
| **Invoice** | Outbound or inbound | ✓ | Settlement |
| **Carrier Packet** | MC cert, insurance, W9, voided check | ✗ | Broker |
| **Insurance** | Policy docs | ✗ | Company |
| **Screenshot** | Reference, misc | ✗ | Optional |

---

## 2. Upload Methods

### Drag & Drop
- Large drop zone, full visual feedback on dragover
- Accepts: PDF, JPG, PNG, HEIC, WEBP, TIFF, XLSX, CSV
- Max 20MB per file, up to 50 files per batch

### Bulk Upload
- Click to select → multi-file picker
- Progress bar per file + overall
- Queue management (pause/cancel individual files)

### Mobile Upload
- QR code generated per session → opens mobile upload page
- Driver photos receipt with phone camera
- HEIC converted server-side

### Email Forwarding
- Unique email address per company: docs@{mc}.hauldesk.io
- Forward fuel receipts, rate cons, invoices directly
- Processed same as upload

---

## 3. Screen Layout

```
┌────────────────────────────────────────────────────────────┐
│ Document Center                          [+ Upload Files]  │
│────────────────────────────────────────────────────────────│
│ ┌─────────────────────────────────────────────────────┐   │
│ │  📂  Drag and drop files here, or click to browse  │   │
│ │  Receipts · Rate Cons · BOLs · Invoices · Packets  │   │
│ └─────────────────────────────────────────────────────┘   │
│────────────────────────────────────────────────────────────│
│ [All] [Receipts] [Rate Cons] [Invoices] [BOL/POD] [Packets]│
│ [Search…] [Date▾] [Status▾] [Sort▾]     [⊞ Grid | ≡ List] │
│────────────────────────────────────────────────────────────│
│ NEEDS REVIEW (3)                                           │
│ [card] [card] [card]                                       │
│                                                            │
│ RECENT UPLOADS                                             │
│ [card] [card] [card] [card] [card] [card]                  │
└────────────────────────────────────────────────────────────┘

DOCUMENT DETAIL DRAWER (560px right slide-in):
├── File preview / thumbnail
├── Document type + status
├── OCR extracted data (editable)
├── Link to load/booking/broker
├── Action buttons
└── Version history
```

---

## 4. Document Card Specification

```
┌──────────────────────────┐
│  [PDF preview / icon]    │
│  📄  ──────────────────  │
│                          │
│  Pilot Flying J          │
│  May 4, 2025             │
│  ─────────────           │
│  💵 $312.40              │
│  🔗 Houston → Van Buren  │
│                          │
│ [RECEIPT] [✓ OCR DONE]  │
└──────────────────────────┘
```

### Status badges
| Status | Color | Meaning |
|---|---|---|
| PROCESSING | Blue pulse | OCR in progress |
| NEEDS REVIEW | Amber | OCR done, low confidence fields |
| APPROVED | Teal | Reviewed and accepted |
| LINKED | Green | Attached to a load/transaction |
| DUPLICATE | Red | Matches existing document |

---

## 5. OCR Pipeline (Phase 2 schema)

```
Upload → R2 storage → BullMQ: ocr-process job
  → AWS Textract (text extraction)
  → Claude Haiku (field structuring)
  → Zod validation
  → Write to receipts + receipt_line_items tables
  → If confidence < 85%: status = 'needs_review'
  → Notify user
```

---

## 6. Carrier Packet Management

Each broker requires a carrier packet before booking. Track status per broker:
- MC Certificate (required)
- COI / Insurance (required, verify expiry)
- W9 (required for payment)
- Voided Check / Bank Info (for factoring)
- Authority Letter (if operating under another MC)

Status: Pending → Submitted → Approved → Expired

---

## 7. Mobile Upload Flow

```
Dispatcher clicks "Mobile Upload"
  → QR code shown (15-min session token)
  → Driver scans QR on phone
  → Opens mobile-optimized upload page
  → Camera or photo picker
  → File uploaded directly to R2
  → Appears in Document Center instantly
  → OCR queued automatically
```

---

## 8. API Endpoints

```
documents.upload(files, type)        → Presigned R2 URL + job queue
documents.list(filters, page)        → Paginated document list
documents.get(id)                    → Document + OCR result
documents.approve(id)                → Mark OCR as approved
documents.reject(id, reason)         → Reject, flag for re-upload
documents.link(id, entityType, entityId) → Attach to load/booking
documents.delete(id)                 → Soft delete
documents.getOCR(id)                 → OCR result + confidence
documents.mobileUploadSession()      → Generate QR token
receipts.list(filters)               → Receipts with OCR data
receipts.updateField(id, field, val) → Edit extracted field
```

*Phase 15 complete — spec delivered. Full document center integrated in portal.*
