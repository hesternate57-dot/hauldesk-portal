# HaulDesk — Phase 4: Application Shell
**Version:** 1.0 | **Phase:** 4 of 21

---

## 1. Shell Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    TOPBAR (sticky, 56px)                │
│  [≡] [Brand] [Breadcrumb]  [Cmd+K Search]  [Theme][🔔][User] │
├──────────────┬──────────────────────────────────────────┤
│              │                                          │
│   SIDEBAR    │            MAIN CONTENT                  │
│  (248px or   │         (scrollable, flex-1)             │
│   52px icon) │                                          │
│              │                                          │
│   [Nav items]│   SCREEN CONTENT                        │
│              │                                          │
│   [User]     │                                          │
└──────────────┴──────────────────────────────────────────┘

Overlays (z-indexed above shell):
├── Command Palette   (Cmd+K, full-screen backdrop)
├── Notification Drawer (right side, 420px slide-in)
└── Mobile Sidebar    (full-width overlay, hamburger trigger)
```

---

## 2. Sidebar Specification

### States
```
Expanded:  248px — icon + label + badge
Collapsed: 52px  — icon only + tooltip on hover
Mobile:    0px   — hidden, opens as full overlay drawer
```

### Collapse Behavior
- Toggle button: bottom-left corner of sidebar, chevron icon
- Persisted in localStorage: `hauldesk_sidebar_collapsed`
- Transition: `width 250ms cubic-bezier(0.4, 0, 0.2, 1)`
- Labels fade out with `opacity 150ms` delay
- Tooltips appear on hover when collapsed (right-side, 160ms delay)
- Keyboard shortcut: `Ctrl/Cmd + B`

### Section Hierarchy
```
Brand (always visible, collapses to mark only)
Portal Switcher (collapses to icon pair)
Nav Sections:
  • Section label (hidden when collapsed)
  • Nav items (icon + label + optional badge/phase tag)
Footer:
  • User chip (avatar + name/role → avatar only when collapsed)
  • Collapse toggle
```

### Active State
- Background: `--teal-s` with left border accent `3px solid --teal`
- Text: `--teal-d` weight 600
- Transition: background 120ms

---

## 3. Topbar Specification

### Layout (left → right)
```
[Hamburger/Collapse] [Brand (mobile only)] [Breadcrumb] 
  [flex spacer] 
  [Search Trigger Cmd+K] [Theme Toggle] [Notifications] [User Menu]
```

### Breadcrumb
- Auto-generated from current screen
- Format: `SECTION / SCREEN NAME`
- Hidden on mobile < 640px

### Search Trigger
- Shows "Search…" placeholder with `⌘K` hint
- Click or Cmd+K opens command palette
- Width: 220px min, expands on focus

---

## 4. Command Palette Specification

### Trigger
- Keyboard: `Cmd+K` (Mac) / `Ctrl+K` (Windows/Linux)
- Click on search bar
- Dismiss: `Esc`, click backdrop

### Layout
```
┌────────────────────────────────────────────┐
│ 🔍  Search HaulDesk...              ⌘K  ✕  │
├────────────────────────────────────────────┤
│ QUICK ACTIONS                              │
│  + New Lane Search                         │
│  + Post a Lane                             │
│  + Invite Team Member                      │
├────────────────────────────────────────────┤
│ RECENT                                     │
│  🚚 Houston → Van Buren (Load #1042)       │
│  🤝 TFSL Logistics (Broker)               │
│  💳 Pilot Flying J $312 (Transaction)     │
├────────────────────────────────────────────┤
│ NAVIGATE                                   │
│  📊 Settlement Dashboard                  │
│  🔐 Roles & Permissions                   │
│  ⚙️  Load Preferences                     │
└────────────────────────────────────────────┘
```

### Keyboard Navigation
```
↑ / ↓       Move selection
Enter        Execute selected item
Esc          Dismiss
Type         Filter results in real-time
```

### Result Categories (when query entered)
- Loads (by route or broker name)
- Brokers (by name or MC)
- Transactions (by merchant or amount)
- Navigation (screen names)
- Settings

---

## 5. Notification Drawer Specification

### Trigger
- Click bell icon in topbar
- Unread count badge (red dot with number)
- Dismiss: click backdrop, click X, or Esc

### Layout
```
┌──────────────────────────────┐
│ Notifications    Mark all  ✕ │
├──────────────────────────────┤
│ [All] [Unread 3] [Approvals] │
├──────────────────────────────┤
│ ● ✅  Booking ready          │
│   Houston → Van Buren $1,600 │
│   Confirm →          2m ago  │
│──────────────────────────────│
│ ● 💬  Broker reply           │
│   Thomas Evans (TFSL)        │
│   View thread →     14m ago  │
│──────────────────────────────│
│   🧾  OCR complete           │
│   3 receipts processed       │
│   Review →           1h ago  │
└──────────────────────────────┘
```

### Notification Types & Icons
```
booking_approval  → ✅  urgent
broker_reply      → 💬  high
ocr_complete      → 🧾  normal
dispatch_status   → 🗺️  normal
ai_insight        → ✨  low
payment_received  → 💰  normal
budget_warning    → ⚠️  high
team_invite       → 👥  normal
```

---

## 6. Theme System

### Tokens
```css
Light mode (default)
  --bg: #f0f5f3
  --card: #ffffff
  --ink: #0f1f1b
  (full token list in Phase 1)

Dark mode ([data-dark] attribute on body)
  --bg: #0a1410
  --card: #0f1e19
  --ink: #eaf5f1
```

### System Preference Detection
```javascript
// On init — respect OS preference
if (!localStorage.getItem('hauldesk_theme')) {
  if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
    document.body.setAttribute('data-dark', '')
  }
}
// Watch for changes
window.matchMedia('(prefers-color-scheme: dark)')
  .addEventListener('change', e => { /* update */ })
```

### Switcher States: Light → Dark → System

---

## 7. Mobile Responsive Specification

### Breakpoints
```
≥ 1024px   Full sidebar (248px or 52px collapsed)
768–1023px Sidebar hidden, hamburger shown, content full width
< 768px    Single column, simplified topbar
```

### Mobile Sidebar Drawer
- Full-height overlay from left
- Backdrop blur behind
- Close on backdrop click or nav item click
- Swipe-to-close (touch events, Phase 7+)

### Topbar (mobile)
```
[☰ Hamburger] [H Logo] [flex spacer] [🔔][User Avatar]
```
Search hidden on mobile topbar — accessed via Cmd+K or dedicated search screen.

---

## 8. Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Cmd/Ctrl + K` | Open command palette |
| `Cmd/Ctrl + B` | Toggle sidebar |
| `Cmd/Ctrl + D` | Toggle dark mode |
| `Esc` | Close any overlay |
| `G then L` | Go to Load Board |
| `G then S` | Go to Settlement |
| `G then T` | Go to Team |
| `?` | Show keyboard shortcuts |

---

## 9. Accessibility

- All interactive elements keyboard-focusable
- Focus trap in overlays (command palette, notification drawer)
- `aria-label` on all icon buttons
- `aria-expanded` on sidebar toggle
- `aria-live="polite"` on notification count
- Reduced motion: `prefers-reduced-motion` disables all transitions
- Color contrast: WCAG AA minimum on all text/background pairs

---

## 10. Component APIs (tRPC)

```
notifications.list(limit, filter)   → paginated notification feed
notifications.markRead(id)          → mark single read
notifications.markAllRead()         → mark all read
notifications.getUnreadCount()      → integer, polled every 30s
search.global(query, limit)         → cross-entity results
user.updatePreferences(prefs)       → theme, sidebar state, etc.
```

*Phase 4 Complete — shell specification delivered. All components integrated in portal.*
