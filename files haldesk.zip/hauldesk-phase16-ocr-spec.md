# HaulDesk — Phase 16: OCR Processing Engine
**Version:** 1.0 | **Phase:** 16 of 21

---

## 1. OCR Pipeline

```
Upload → R2 Storage
  → BullMQ: ocr-process job
  → AWS Textract (FORMS + TABLES features)
      Returns: key-value pairs, table cells, raw blocks, confidence per field
  → Claude Haiku (structuring + categorization)
      Input: Textract raw output
      Output: structured JSON with field names, values, confidence
  → Zod validation
  → Write: receipts + receipt_line_items tables
  → Confidence check:
      All fields ≥ 85% → status = 'approved', notify user
      Any field < 85%  → status = 'needs_review', notify dispatcher
  → If duplicate detected → status = 'duplicate', flag for review
```

---

## 2. Field Extraction Targets

| Field | Source | Confidence Threshold |
|---|---|---|
| Vendor name | Key-value + header detection | 80% |
| Vendor address | Key-value | 75% |
| Date | Key-value + date parsing | 90% |
| Time | Key-value | 85% |
| Invoice / Receipt # | Key-value + regex | 85% |
| Subtotal | Key-value + amount detection | 95% |
| Tax | Key-value | 90% |
| Tip | Key-value | 90% |
| Total | Key-value + amount detection | 95% |
| Payment method | Key-value | 80% |
| Category | Claude Haiku classification | 88% |
| Line items | Table extraction | 80% per row |

---

## 3. Confidence Scoring

```
Per field:
  HIGH   ≥ 85%  → Green · auto-accepted
  MEDIUM 70–84% → Amber · flagged for review
  LOW    < 70%  → Red   · must be corrected before approval

Document overall:
  All HIGH     → auto-approve, link to transaction
  Any MEDIUM   → send to review queue
  Any LOW      → send to review queue, highlight bad fields
  Duplicate    → block approval, show matching document
```

---

## 4. Review Screen Layout

```
┌──────────────────────────────────────────────────────────┐
│ OCR Review Queue                    [3 pending] [Batch ▾]│
├──────────────────────────────────────────────────────────┤
│ [Queue list — 3 items]                                   │
│  📄 TA_Petro_receipt · $284.10 · ⚠ Possible duplicate   │
│  📸 IMG_4821_fuel   · $198.40 · ⚠ Low confidence        │
│  📄 Speedco_invoice · $248.00 · ⚠ Unlinked             │
└──────────────────────────────────────────────────────────┘

OCR REVIEW PANEL (full-width, opens on click):
┌──────────────────────┬───────────────────────────────────┐
│  DOCUMENT PREVIEW    │  EXTRACTED FIELDS                 │
│                      │                                   │
│  [Simulated receipt  │  Vendor      [TA Petro    ] ✓95% │
│   with highlighted   │  Date        [May 2, 2025 ] ✓98% │
│   field regions]     │  Receipt #   [R-204819   ] ⚠71% │
│                      │  Subtotal    [$261.30     ] ✓96% │
│                      │  Tax         [$22.80      ] ✓94% │
│                      │  Total       [$284.10     ] ✓99% │
│                      │  Category    [Fuel        ] ✓88% │
│                      │  Payment     [EFS Card    ] ⚠73% │
│                      │                                   │
│                      │  ⚠ DUPLICATE WARNING             │
│                      │  Matches: TA_Petro_May02b         │
│                      │                                   │
│  [◀ Prev] [Next ▶]  │  [Reject] [Skip] [Approve →]     │
└──────────────────────┴───────────────────────────────────┘
```

---

## 5. Correction Workflow

```
Field states:
  ACCEPTED  → green checkmark, value locked
  FLAGGED   → amber warning, value editable
  ERROR     → red X, value must be edited before approve
  EDITED    → blue pencil, value was manually changed

Actions:
  Click field value → inline edit input appears
  Press Enter / click ✓ → save edit, mark as EDITED
  Press Escape → cancel edit
  "Accept all high confidence" → bulk-accept all ≥ 85% fields
  "Approve" → requires all fields ACCEPTED or EDITED
  "Reject" → prompts for reason, marks document rejected
  "Skip" → moves to next in queue, returns later
  "Flag as duplicate" → links to existing document
```

---

## 6. Line Items Extraction

For invoices and multi-line receipts:

```
┌──────────────────────────────────────────────────┐
│ LINE ITEMS                          [+ Add Row]  │
├──────────┬───────────┬──────┬───────┬────────────┤
│ Item     │ Qty       │ Unit │ Price │ Total      │
├──────────┼───────────┼──────┼───────┼────────────┤
│ DEF Fuel │ 42.3 gal  │ gal  │ $4.82 │ $203.89 ✓ │
│ Additives│ 1         │ ea   │ $57.41│ $57.41  ✓ │
└──────────┴───────────┴──────┴───────┴────────────┘
  Subtotal: $261.30  Tax: $22.80  Total: $284.10 ✓
```

---

## 7. Approval Workflow

```
All fields reviewed →
  "Approve" clicked →
    Link to transaction? [Auto-match | Select | Create new]
    Category confirmed? [Fuel ▾]
    → Write to receipts table: status = 'approved'
    → Write to transactions table if new
    → Create receipt_line_items records
    → Notify: "Receipt approved and linked"
    → Remove from queue

"Reject" clicked →
  Reason required: [Poor quality | Wrong document | Duplicate | Other]
  → Write: status = 'rejected', rejection_reason
  → Notify: "Document rejected — {reason}"
  → Can request re-upload from driver
```

---

## 8. API Endpoints

```
ocr.getQueue(filters)          → Pending review items
ocr.getResult(receiptId)       → Full OCR data + confidence
ocr.updateField(id, field, val)→ Edit extracted field
ocr.acceptField(id, field)     → Mark field accepted
ocr.acceptAll(id)              → Accept all high-confidence fields
ocr.approve(id, linkTo)        → Approve + link to transaction
ocr.reject(id, reason)         → Reject document
ocr.skip(id)                   → Defer to later
ocr.flagDuplicate(id, matchId) → Mark as duplicate
ocr.reprocess(id)              → Re-run OCR on document
```

*Phase 16 complete — all OCR screens integrated in portal.*
